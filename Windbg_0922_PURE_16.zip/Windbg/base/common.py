# coding=utf-8

import json
import os
import shutil
import sys
import logging
import time
import datetime
import re
from base.helper import *
from base import fileOP
from base.contants import *

def dump_result_yaml(result_dict, command_his, command_dict,  dir_name):
    # last dump
    result_yaml_file = 'result.yaml'
    result_yaml_file = os.path.join(dir_name, result_yaml_file)
    fileOP.dump_file(result_yaml_file, result_dict)

    # command list
    result_yaml_file = 'command_list.yaml'
    result_yaml_file = os.path.join(dir_name, result_yaml_file)
    fileOP.dump_file(result_yaml_file, command_his)

    # command
    result_yaml_file = 'command_dict.yaml'
    result_yaml_file = os.path.join(dir_name, result_yaml_file)
    fileOP.dump_file(result_yaml_file, command_dict)
    return

def parse_blocked_IRP_address(cmd_output_list, result_dict, blocked_IRP_address):
    blocked_device_Address = None
    # logger.info(f'blocked_irp_context: {result}')
    # logger.info(f'result_dict: {result_dict}')
    has_flag = False
    if cmd_output_list:
        result_dict['blocked_irp_context'] = cmd_output_list

        for idx, line in enumerate(cmd_output_list):
            line = line.strip()
            # logger.info(f'line: {line}, idx: {idx}')
            # case 7, 12
            if '>' in line and 'kd>' not in line:
                has_flag = True
                flag_idx = idx
                continue
            if '\\Driver\\' in line and has_flag:
                logger.info(f'line: {line}')
                blocked_irp_driver = get_driver(line)
                result_dict['blocked_irp_driver'] = blocked_irp_driver
                logger.info(f'blocked_irp_driver: {blocked_irp_driver}')

                # address, case:4.1
                split_list = cmd_output_list[flag_idx+1].split(' ')
                if len(split_list) >=4:
                    blocked_device_Address = split_list[3]
                    logger.info(f'blocked_device_Address: {blocked_device_Address}')
                    result_dict['blocked_device_Address'] = blocked_device_Address
                break

    return blocked_device_Address

def get_blocked_IRP_address(cmd_output_list, result_dict):
    blocked_IRP_address = None
    if cmd_output_list:
        result_dict['Locks_thread_context'] = cmd_output_list

        for idx, line in enumerate(cmd_output_list):
            line = line.strip()
            if 'IRP List' in line:
                logger.info(f'IRP List: {line}')
                blocked_IRP_address = cmd_output_list[idx + 1].split(':')[0]
                logger.info(f'blocked_IRP_address: {blocked_IRP_address}')
                result_dict['blocked_IRP_address'] = blocked_IRP_address

    return blocked_IRP_address

def parse_locks_info(cmd_output_list, result_dict):
    new_result = get_list_strip(cmd_output_list)
    result_dict['Locks_Context'] = new_result

    # 执行解析
    # logger.info(f'file_content_new: {file_content_new}')
    thread_contention_pairs,Locks_thread_Address = fileOP.parse_locks_content(new_result)
    logger.info(f'thread_contention_pairs: {thread_contention_pairs}')
    Locks_thread_Address = Locks_thread_Address.replace('-01<*>', '')
    logger.info(f'Locks_thread_Address: {Locks_thread_Address}')

    result_dict['Locks_thread_Address'] = Locks_thread_Address
    result_dict['blocked_thread_Address'] = Locks_thread_Address

    if Locks_thread_Address:
        result_dict['Locks_thread_Status'] = 1
    else:
        result_dict['Locks_thread_Status'] = 0

    return Locks_thread_Address


def parse_vertarget(cmd_output, result_dict):
    result_dict['vertarget_Context'] = cmd_output

    cmd_output_list = cmd_output.splitlines()
    OS_Version_ID = None
    if cmd_output_list:
        OS_Version_ID = get_list_text_line(cmd_output_list, 'Edition build lab')

    result_dict['OS_Version_ID'] = OS_Version_ID
    return

def parse_sysinfo_cpuspeed(cmd_output, result_dict):
    result_dict['cpuspeed_context'] = cmd_output

    cmd_output_list = cmd_output.splitlines()
    CPUID = None
    if cmd_output_list:
        CPUID = get_list_text_line(cmd_output_list, 'CPUID:')
        logger.info(f'CPUID: {CPUID}')
        CPUID = CPUID.replace('CPUID:', '')
        CPUID = CPUID.replace('1: kd>', '').strip()
        logger.info(f'CPUID: {CPUID}')

    result_dict['CPUID'] = CPUID
    return

def parse_amli_r(cmd_output_list, result_dict):
    ACPI_Method_AMLPointer = ''
    new_result = get_list_strip(cmd_output_list)
    logger.info(f'new_result: {new_result}')
    result_dict['ACPI_Method_Context'] = new_result

    ACPI_Method_AMLPointer = get_list_text_line(cmd_output_list, 'Next AML Pointer:')

    result_dict['ACPI_Method_AMLPointer'] = ACPI_Method_AMLPointer
    return

def parse_ndiskd_netadapter(cmd_output_list, result_dict, Ndis_netadapter_address):
    # logger.info('parse_Power_0x9f_3_key_words')
    # start_text = f'kd> !ndiskd.netadapter {Ndis_netadapter_address}'
    # result = fileOP.get_text_with_start_text_to_end( start_text)

    Ndis_netadapter1_address = result_dict['Ndis_netadapter1_address']
    if Ndis_netadapter_address == Ndis_netadapter1_address:
        result_dict['NDIS_netadapter1_Context'] = cmd_output_list
    else:
        result_dict['NDIS_netadapter2_Context'] = cmd_output_list
    return

def parse_ndiskd_oid(cmd_output_list, result_dict):
    # logger.info('parse_Power_0x9f_3_key_words')
    # start_text = f'kd> !ndiskd.oid'
    # result = fileOP.get_text_with_start_text_to_end( start_text)
    result_dict['NDIS_OID_Context'] = cmd_output_list

    Ndis_netadapter1_address = None
    Ndis_netadapter2_address = None

    text_lines = get_list_text_lines(cmd_output_list, 'NetAdapter')
    if text_lines:
        NDIS_OID_Pending_Status = 1
        text_line = text_lines[0].replace('NetAdapter', '').strip()
        temp_list = text_line.split('-')
        Ndis_netadapter1_address = temp_list[0]
        Ndis_netadapter1_name = temp_list[1]

        logger.info(f'NDIS_netadapter1_address: {Ndis_netadapter1_address}')
        logger.info(f'Ndis_netadapter1_name: {Ndis_netadapter1_name}')

        result_dict['Ndis_netadapter1_address'] = Ndis_netadapter1_address
        result_dict['Ndis_netadapter1_name'] = Ndis_netadapter1_name

        # 2
        text_line = text_lines[1].replace('NetAdapter', '').strip()
        temp_list = text_line.split('-')
        Ndis_netadapter2_address = temp_list[0]
        Ndis_netadapter2_name = temp_list[1]

        logger.info(f'Ndis_netadapter2_address: {Ndis_netadapter2_address}')
        logger.info(f'Ndis_netadapter2_name: {Ndis_netadapter2_name}')

        result_dict['Ndis_netadapter2_address'] = Ndis_netadapter2_address
        result_dict['Ndis_netadapter2_name'] = Ndis_netadapter2_name
    else:
        NDIS_OID_Pending_Status = 0

    result_dict['NDIS_OID_Pending_Status'] = NDIS_OID_Pending_Status

    return Ndis_netadapter1_address, Ndis_netadapter2_address

def parse_analyze_v(cmd_output, result_dict):
    cmd_output_list = cmd_output.splitlines()

    start_text = f'*******************************************************************************'
    end_text = 'Debugging Details:'

    result_list = fileOP.get_text_with_start_and_end(cmd_output_list, start_text, end_text)
    trip_list = get_list_strip(result_list)
    result_dict['Bugcheck_Analysis'] = '\n' + '\n'.join(trip_list)

    item_list = ['BUGCHECK_CODE', 'BUGCHECK_P1', 'BUGCHECK_P2', 'BUGCHECK_P3', 'BUGCHECK_P4', 'FAILURE_BUCKET_ID', 'MODULE_NAME']

    update_dict_by_parse(cmd_output_list, item_list, result_dict)

    count = get_list_text_count(cmd_output_list, 'DISK_HARDWARE_ERROR')
    if count:
        result_dict['DISK_HARDWARE_ERROR_Status'] = 1
    else:
        result_dict['DISK_HARDWARE_ERROR_Status'] = 0

    # Trap_Frame_Context
    start_text = f'CONTEXT:'
    end_text = 'Resetting default scope'
    result = fileOP.get_text_with_start_and_end(cmd_output_list, start_text, end_text)
    result_dict['Trap_Frame_Context'] = result

    content_count = get_list_text_count(result, '=?')
    if content_count:
        Conext_Memory_Corruption_Status = 1
    else:
        Conext_Memory_Corruption_Status = 0

    result_dict['Conext_Memory_Corruption_Status'] = Conext_Memory_Corruption_Status

    # Stack_Text
    start_text = f'STACK_TEXT:'
    end_text = 'SYMBOL_NAME:'
    result = fileOP.get_text_with_start_and_end(cmd_output_list, start_text, end_text)
    result_dict['Stack_Text'] = result

    Stack_Memory_Operation_Status = 0
    if result:
        Stack_Memory_Operation_Status = get_Stack_Memory_Operation_Status(result)
    result_dict['Stack_Memory_Operation_Status'] = Stack_Memory_Operation_Status

    Memory_Status_Abnormal = 0
    if Conext_Memory_Corruption_Status or Stack_Memory_Operation_Status:
        Memory_Status_Abnormal = 1

    result_dict['Memory_Status_Abnormal'] = Memory_Status_Abnormal

    return

def get_driver(input_str):
    # 定义要匹配的前缀
    prefix = '\\Driver\\'

    # 检查字符串是否包含目标前缀
    if prefix in input_str:
        # 找到前缀结束的位置
        prefix_end_index = input_str.find(prefix) + len(prefix)

        # 从 prefix 结束位置开始，截取到制表符(\t)出现的位置
        # 因为原字符串中 igfx 后面是制表符分隔
        tab_index = input_str.find('\t', prefix_end_index)

        # 提取目标字段
        if tab_index != -1:
            target_field = input_str[prefix_end_index:tab_index]
            # logger.info(f"提取到的字段: {target_field}")  # 输出: igfx
        else:
            # 如果没有制表符，直接取剩余全部内容
            target_field = input_str[prefix_end_index:]
            # logger.info(f"提取到的字段: {target_field}")
    else:
        logger.info(f"字符串中不包含前缀: {prefix}")

    return target_field

def parse_amli_lc(cmd_output_list, result_dict):
    ACPI_Method_Address = ''
    ACPI_Method_Object = ''
    ACPI_Method_Status = 0
    for item in cmd_output_list:
        logger.info(f"item: {item}")
        if 'Ctxt=' in item:
            ACPI_Method_Address = re.findall(r'Ctxt=(.*?),', item)
            ACPI_Method_Address = ACPI_Method_Address[0]
            ACPI_Method_Status = 1
        if 'Obj=' in item:
            prefix = "Obj="
            # 查找前缀在字符串中的位置
            prefix_index = item.find(prefix)
            if prefix_index != -1:
                # 提取前缀后面的所有内容（从prefix结束位置开始截取）
                ACPI_Method_Object = item[prefix_index + len(prefix):]
                ACPI_Method_Object = ACPI_Method_Object.strip()
                logger.info(f"提取到的Obj字段值: {ACPI_Method_Object}")  # 输出: _SB,hello
            else:
                logger.info(f"字符串中未找到 '{prefix}'")
            ACPI_Method_Status = 1

    result_dict['ACPI_Method_Status'] = ACPI_Method_Status
    result_dict['ACPI_Method_Address'] = ACPI_Method_Address
    result_dict['ACPI_Method_Object'] = ACPI_Method_Object

    logger.info(f"ACPI_Method_Address: {ACPI_Method_Address}")
    logger.info(f"ACPI_Method_Object: {ACPI_Method_Object}")
    logger.info(f"ACPI_Method_Status: {ACPI_Method_Status}")
    return


def parse_storadapter_storadapter_adapter_address_sub(cmd_output_list, result_dict):
    line = get_list_text_line_after_line(cmd_output_list, 'Product','Working')
    logger.info(f'Working line:{line}')
    split_list = line.split(' ')
    logger.info(f'split_list:{split_list}')
    storadapter_storunit1_address = get_list_first_valide_value(split_list)
    result_dict['storadapter_storunit1_address'] = storadapter_storunit1_address

    line = get_list_text_line_after_line(cmd_output_list, 'Product','SurpriseRemoval')
    logger.info(f'SurpriseRemoval line:{line}')
    storadapter_storunit2_address = get_list_first_valide_value(split_list)
    result_dict['storadapter_storunit2_address'] = storadapter_storunit2_address
    return

def parse_storadapter_storadapter_adapter_address(cmd_output_list, result_dict):
    result_dict['storadapter_adapter1_Context'] = cmd_output_list

    count = get_list_text_count(cmd_output_list, 'SurpriseRemoval')
    if count:
        storadapter_adapter1_SurpriseRemoval_Status = 1
    else:
        storadapter_adapter1_SurpriseRemoval_Status = 0
    result_dict['storadapter_adapter1_SurpriseRemoval_Status'] = storadapter_adapter1_SurpriseRemoval_Status

    if count:
        parse_storadapter_storadapter_adapter_address_sub(cmd_output_list, result_dict)

    return

def parse_storadapter(cmd_output_list, result_dict):
    for idx, line in enumerate(cmd_output_list):
        # logger.info(f'line: {line}')

        if 'Driver' in line and 'Object' in line:
            split_list = cmd_output_list[idx + 2].split(' ')
            logger.info(f'split_list: {split_list}')

            storadapter_adapter1_driver = split_list[0]
            logger.info(f'storadapter_adapter1_driver: {storadapter_adapter1_driver}')
            result_dict['storadapter_adapter1_driver'] = storadapter_adapter1_driver

            for idx, line in enumerate(split_list):
                if '' != line and idx > 0:
                    result_dict['storadapter_adapter1_address'] = line
                    logger.info(f'storadapter_adapter1_address: {line}')
                    break

    return

def parse_storagekd_storclass(cmd_output_list, result_dict):
    result_dict['Storclass_FDO1_Context'] = cmd_output_list

    # need logic
    count = get_list_text_count(cmd_output_list, 'Retried')
    if count > 4:
        Storclass_FDO1_Failed_Requests_Status = 1
    else:
        Storclass_FDO1_Failed_Requests_Status = 0

    result_dict['Storclass_FDO1_Failed_Requests_Status'] = Storclass_FDO1_Failed_Requests_Status

    return

def parse_storclass(result_list, result_dict):
    for idx, line in enumerate(result_list):
        if 'FDO' in line and '# Device ID' in line:
            Storclass_FDO1_address = result_list[idx + 2]
            logger.info(f'Storclass_FDO1: {Storclass_FDO1_address}')
            split_list = Storclass_FDO1_address.split(' ')
            logger.info(f'split_list: {split_list}')

            Storclass_FDO1_address = split_list[0]
            Storclass_FDO1_DeviceID = f'{split_list[5]} {split_list[6]}'

            logger.info(f'Storclass_FDO1_DeviceID: {Storclass_FDO1_DeviceID}')
            logger.info(f'Storclass_FDO1_address: {Storclass_FDO1_address}')

            result_dict['Storclass_FDO1_address'] = Storclass_FDO1_address
            result_dict['Storclass_FDO1_DeviceID'] = Storclass_FDO1_DeviceID

    # result_dict['NDIS_OID_Context'] = result

    return


def parse_powertriage(cmd_output_list, result_dict):
    # logger.info(f'result_dict type: {type(result_dict)}')

    # # Power Action
    start_text = f'Power Action:'
    start_index_offset = 6
    end_text = f'State.:'
    result = fileOP.get_text_with_start_text_with_offset(cmd_output_list, start_text, start_index_offset)

    tmp_list = []

    line = get_list_text_line(result, 'PopAction :')
    logger.info(f'line: {line}')
    logger.info(f'line type: {type(line)}')
    if line:
        result_dict['System_State_Context'] = line

    # PCI
    start_text = f'+  PCI\\VEN_'
    end_text = f'+  USB\\'
    result = fileOP.get_text_with_start_and_end(cmd_output_list, start_text, end_text)

    text_lines = get_list_strip(result)
    if text_lines:
        result_dict['Device_State_Context'] = text_lines

    return

def parse_devstack(cmd_output_list, result_dict):
    result_dict['blocked_device_Context'] = cmd_output_list

    line = get_list_text_line(cmd_output_list, 'ServiceName is')
    if line:
        line = line.replace('ServiceName is', '')
        line = line.replace('"', '').strip()
        result_dict['blocked_device_ServiceName'] = line

    line = get_list_text_line(cmd_output_list, 'DeviceInst is')
    if line:
        line = line.replace('DeviceInst is', '')
        line = line.replace('"', '').strip()
        result_dict['blocked_device_DeviceInst'] = line

    line = get_list_text_line(cmd_output_list[1:], '>')
    # logger.info(f'line: {line}')
    if line:
         split_list = line.split(' ')
         # logger.info(f'split_list: {split_list}')

         new_list = get_list_strip(split_list)
         # logger.info(f'new_list: {new_list}')

         blocked_device_DevExta_address = new_list[3]
         logger.info(f'blocked_device_DevExta_address: {blocked_device_DevExta_address}')
         result_dict['blocked_device_DevExta_address'] = blocked_device_DevExta_address
    return

if __name__ == '__main__':
    logger.info('common hello')
    pass

# coding=utf-8

import json
import os
import shutil
import sys
import logging
import time
import datetime
import re
import subprocess
from base.contants import *
from base.helper import *
from base import common
from base.AdvancedWinDbgInterface import *


def analyze_v_run(result_dict):
    # time.sleep(3)  # 等待初始化
    cmd = "!analyze -v"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    logger.info(f'cmd_output type:\n{cmd_output}')

    common.parse_analyze_v(cmd_output, result_dict)
    return

def thread_blocked_thread_Address(result_dict,blocked_thread_Address):
    cmd = f"!thread {blocked_thread_Address}"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    cmd_output_list = cmd_output.splitlines()
    blocked_IRP_address = common.get_blocked_IRP_address(cmd_output_list, result_dict)

    return blocked_IRP_address

def irp_blocked_IRP_address(result_dict, blocked_IRP_address):
    cmd = f"!irp {blocked_IRP_address}"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    cmd_output_list = cmd_output.splitlines()

    blocked_device_Address = common.parse_blocked_IRP_address(cmd_output_list, result_dict, blocked_IRP_address)

    return blocked_device_Address

def devstack_blocked_device_Address(result_dict, blocked_device_Address):
    # !devstack blocked_device_Address
    cmd = f"!devstack {blocked_device_Address}"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    # logger.info(f'cmd_output: {cmd_output}')

    cmd_output_list = cmd_output.splitlines()
    common.parse_devstack(cmd_output_list, result_dict)
    return

def powertriage(result_dict):
    # logger.info(f'result_dict type: {type(result_dict)}')

    # !powertriage
    cmd = f"!powertriage"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    cmd_output_list = cmd_output.splitlines()
    common.parse_powertriage(cmd_output_list, result_dict)

    blocked_irp_driver = result_dict.get('blocked_irp_driver', None)
    result_dict['BSOD_Supcious_Driver'] = blocked_irp_driver

    blocked_device_DeviceInst = result_dict.get('blocked_device_DeviceInst', None)
    result_dict['BSOD_Supcious_Device'] = blocked_device_DeviceInst
    return

def amli_r_ACPI_Method_Address(result_dict):
    ACPI_Method_Address = result_dict['ACPI_Method_Address']
    cmd = f"!amli r {ACPI_Method_Address}"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)
    # time.sleep(15)

    cmd_output_list = cmd_output.splitlines()
    common.parse_amli_r(cmd_output_list, result_dict)
    return

def amli_lc_ACPI_Method_Address(result_dict):
    cmd = f"!amli lc"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    logger.info(f'amli lc: {cmd_output}')

    cmd_output_list = cmd_output.splitlines()
    common.parse_amli_lc(cmd_output_list, result_dict)
    return

def locks(result_dict):
    cmd = "!locks"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    cmd_output_list = cmd_output.splitlines()

    blocked_thread_Address = common.parse_locks_info(cmd_output_list, result_dict)

    return blocked_thread_Address

def pnptriage(result_dict):
    cmd = "!pnptriage"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    cmd_output_list = cmd_output.splitlines()
    blocked_IRP_address = common.get_blocked_IRP_address(cmd_output_list, result_dict)
    if blocked_IRP_address:
        result_dict['blocked_IRP_address_status'] = 1
    else:
        result_dict['blocked_IRP_address_status'] = 0

    return

if __name__ == '__main__':
    # cmd = " ".join(args)
    # result, errors, return_code = cmd_excute(cmd)
    # logger.info(f'result:{result}, errors:{errors}, return_code:{return_code}')
    #
    # cmd = 'qqd'
    # result, errors, return_code = cmd_excute(cmd)
    # logger.info(f'result:{result}, errors:{errors}, return_code:{return_code}')
    pass

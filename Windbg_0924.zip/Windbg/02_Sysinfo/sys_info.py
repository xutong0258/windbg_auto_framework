import os
from base import fileOP
from base import common
from base.componet import *
from base.one_step_sop import *

path_dir = os.path.dirname(__file__)

if __name__ == '__main__':
    src_dir = r'E:\BSOD_Debug_SOP_0911\2. Sysinfo\2.1 0x124_0_Machine Check Error'
    dump_file = os.path.join(src_dir, 'MEMORY.DMP')
    # tool_log_file = os.path.join(src_dir, 'hello.log')

    log_file = os.path.join(path_dir, 'tmp.log')
    result_dict = {}

    # start
    if not windbg.start(target=dump_file):
        assert ('FAIL')

    try:
        analyze_v_run(result_dict)

        BUGCHECK_CODE = result_dict.get('BUGCHECK_CODE')

        # if BUGCHECK_CODE and BUGCHECK_CODE == '124':
        #     WHEA_0x124_run(result_dict)

        system_info_run(result_dict)

        command_his, command_dict = windbg.get_total_cmd()
    finally:
        windbg.stop()

    common.dump_result_yaml(result_dict, command_his, command_dict , path_dir)
    pass
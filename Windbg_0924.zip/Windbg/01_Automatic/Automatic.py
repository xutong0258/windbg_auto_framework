import os
from base import fileOP
from base import common
from base.componet import *
from base.one_step_sop import *

path_dir = os.path.dirname(__file__)


if __name__ == '__main__':
    src_dir = r'E:\BSOD_Debug_SOP_0911\1. Automatic\1.3 0xEF_Context Memory Corruption'
    src_dir = r'E:\BSOD_Debug_SOP_0911\1. Automatic\1.2 0x1A_Call Stack MI'
    src_dir = r'E:\BSOD_Debug_SOP_0911\1. Automatic\1.4 0xA_ Trap Frame Memory Corruption'
    src_dir = r'E:\BSOD_Debug_SOP_0911\1. Automatic\1.5 Disk_0x7A_SurpriseRemoval'
    src_dir = r'E:\BSOD_Debug_SOP_0911\1. Automatic\1.1 0x3b_Context Memory Corruption'

    # src_dir = r'D:\0_LOG_VIP\11_Power_0x9f_3\11.1_0x9f_3_igfx'
    dump_file = os.path.join(src_dir, 'MEMORY.DMP')
    # tool_log_file = os.path.join(src_dir, 'hello.log')

    log_file = os.path.join(path_dir, 'tmp.log')
    result_dict = {}

    # start
    if not windbg.start(target=dump_file):
        assert ('FAIL')

    try:
        analyze_v_run(result_dict)

        command_his, command_dict = windbg.get_total_cmd()
    finally:
        windbg.stop()

    common.dump_result_yaml(result_dict, command_his, command_dict , path_dir)

    pass
# coding=utf-8

import json
import os
import shutil
import sys
import logging
import time
import datetime
import re
import subprocess
from base.contants import *
from base.helper import *
from base import common
from base.AdvancedWinDbgInterface import *


def analyze_v_run(result_dict):
    # time.sleep(3)  # 等待初始化
    cmd = "!analyze -v"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    # logger.info(f'cmd_output type:\n{cmd_output}')

    common.parse_analyze_v(cmd_output, result_dict)
    return

def thread_blocked_thread_Address(result_dict,blocked_thread_Address):
    cmd = f"!thread {blocked_thread_Address}"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    cmd_output_list = cmd_output.splitlines()
    blocked_IRP_address = common.get_blocked_IRP_address(cmd_output_list, result_dict)

    count = get_list_text_count(cmd_output_list, 'nt!PopFxActivateDevice')
    # nt!PopFxActivateDevice_Status = 1
    # nt!PopFxActivateDevice_frameNo = 4
    if count:
        PopFxActivateDevice_Status = 1
        PopFxActivateDevice_frameNo = 4
        result_dict['nt!PopFxActivateDevice_Status'] = PopFxActivateDevice_Status
        result_dict['nt!PopFxActivateDevice_frameNo'] = PopFxActivateDevice_frameNo

    return blocked_IRP_address

def irp_blocked_IRP_address(result_dict, blocked_IRP_address):
    cmd = f"!irp {blocked_IRP_address}"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    cmd_output_list = cmd_output.splitlines()

    blocked_device_Address = common.parse_blocked_IRP_address(cmd_output_list, result_dict)

    return blocked_device_Address

def devstack_blocked_device_Address(result_dict, blocked_device_Address):
    # !devstack blocked_device_Address
    cmd = f"!devstack {blocked_device_Address}"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    # logger.info(f'cmd_output: {cmd_output}')

    cmd_output_list = cmd_output.splitlines()
    common.parse_devstack(cmd_output_list, result_dict)
    return

def powertriage(result_dict):
    # logger.info(f'result_dict type: {type(result_dict)}')

    # !powertriage
    cmd = f"!powertriage"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    cmd_output_list = cmd_output.splitlines()
    common.parse_powertriage(cmd_output_list, result_dict)

    blocked_IRP_driver = result_dict.get('blocked_IRP_driver', None)
    if blocked_IRP_driver:
        result_dict['BSOD_Supcious_Driver'] = blocked_IRP_driver
    logger.info(f'BSOD_Supcious_Driver: {blocked_IRP_driver}')

    blocked_device_ServiceName = result_dict.get('blocked_device_ServiceName', None)
    blocked_device_DeviceInst = result_dict.get('blocked_device_DeviceInst', None)
    if blocked_device_ServiceName and blocked_device_DeviceInst:
        BSOD_Supcious_Device =  f'{blocked_device_ServiceName} {blocked_device_DeviceInst}'
        result_dict['BSOD_Supcious_Device'] = BSOD_Supcious_Device
        logger.info(f'BSOD_Supcious_Device: {BSOD_Supcious_Device}')

    blocked_IRP_address_status = result_dict.get('blocked_IRP_address_status', None)
    PopFxActivateDevice_Status = result_dict.get('nt!PopFxActivateDevice_Status', None)

    result_dict['locks_thread_Status_Abnormal'] = 0
    if blocked_IRP_address_status or PopFxActivateDevice_Status:
        result_dict['locks_thread_Status_Abnormal'] = 1
    return

def amli_r_ACPI_Method_Address(result_dict):
    ACPI_Method_Address = result_dict['ACPI_Method_Address']
    cmd = f"!amli r {ACPI_Method_Address}"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)
    # time.sleep(15)

    cmd_output_list = cmd_output.splitlines()
    common.parse_amli_r(cmd_output_list, result_dict)
    return

def amli_lc_ACPI_Method_Address(result_dict):
    cmd = f"!amli lc"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    logger.info(f'amli lc: {cmd_output}')

    cmd_output_list = cmd_output.splitlines()
    common.parse_amli_lc(cmd_output_list, result_dict)
    return

def locks(result_dict):
    cmd = "!locks"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    cmd_output_list = cmd_output.splitlines()

    blocked_thread_Address = common.parse_locks_info(cmd_output_list, result_dict)

    return blocked_thread_Address

def pnptriage(result_dict):
    cmd = "!pnptriage"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    cmd_output_list = cmd_output.splitlines()
    common.get_blocked_IRP_address(cmd_output_list, result_dict)
    return

def frame_r_nt_PopFxActivateDevice_frameNo(result_dict):
    PopFxActivateDevice_frameNo = result_dict.get('nt!PopFxActivateDevice_frameNo', None)
    if PopFxActivateDevice_frameNo is None:
        return

    cmd = f".frame /r {PopFxActivateDevice_frameNo}"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    cmd_output_list = cmd_output.splitlines()

    target_line = get_list_text_line(cmd_output_list, 'rbx=')
    logger.info(f'target_line: {target_line}')

    match = re.search(r'rbx=(.*) ', target_line)

    if match:
        PopFxActivateDevice = match.group()
        logger.info(f"PopFxActivateDevice：{PopFxActivateDevice}")
        PopFxActivateDevice = PopFxActivateDevice.replace('rbx=', '')
        PopFxActivateDevice = PopFxActivateDevice.strip()
        logger.info(f"PopFxActivateDevice：{PopFxActivateDevice}")
        result_dict['nt!PopFxActivateDevice'] = PopFxActivateDevice
        result_dict['nt!PopFxActivateDevice_address'] = PopFxActivateDevice
    else:
        logger.info("未找到: (.*)_IRP")

    return

# dt _pop_fx_device nt!PopFxActivateDevice_address
# dt_pop_fx_device_nt_PopFxActivateDevice_address
def dt_pop_fx_device_nt_PopFxActivateDevice_address(result_dict):
    PopFxActivateDevice_address = result_dict.get('nt!PopFxActivateDevice_address', None)
    if PopFxActivateDevice_address is None:
        return
    cmd = f"dt _pop_fx_device {PopFxActivateDevice_address}"
    logger.info(f'cmd: {cmd}')
    cmd_output = windbg.execute_command(cmd, timeout=15)

    cmd_output_list = cmd_output.splitlines()

    target_line = get_list_text_line(cmd_output_list, 'Irp')
    logger.info(f'target_line: {target_line}')

    match = re.search(r': (.*) _IRP', target_line)

    if match:
        blocked_device_address = match.group()
        blocked_device_address = blocked_device_address.replace(': ', '')
        blocked_device_address = blocked_device_address.replace('_IRP', '')
        blocked_device_address = blocked_device_address.strip()
        logger.info(f"blocked_device_address：{blocked_device_address}")
        result_dict['blocked_device_address'] = blocked_device_address
    else:
        logger.info("未找到: (.*)_IRP")

    target_line = get_list_text_line(cmd_output_list, 'DeviceObject')
    logger.info(f'target_line: {target_line}')

    match = re.search(r': (.*) _DEVICE_OBJECT', target_line)

    if match:
        blocked_IRP_address = match.group()
        blocked_IRP_address = blocked_IRP_address.replace(': ', '')
        blocked_IRP_address = blocked_IRP_address.replace('_DEVICE_OBJECT', '')
        blocked_IRP_address = blocked_IRP_address.strip()
        logger.info(f"blocked_IRP_address：{blocked_IRP_address}")
        result_dict['blocked_IRP_address'] = blocked_IRP_address
    else:
        logger.info("未找到:': (.*) _DEVICE_OBJECT'")

    return

if __name__ == '__main__':
    # cmd = " ".join(args)
    # result, errors, return_code = cmd_excute(cmd)
    # logger.info(f'result:{result}, errors:{errors}, return_code:{return_code}')
    #
    # cmd = 'qqd'
    # result, errors, return_code = cmd_excute(cmd)
    # logger.info(f'result:{result}, errors:{errors}, return_code:{return_code}')
    pass

# coding=utf-8

import json
import os
import shutil
import sys
import logging
import time
import datetime
import re
import cv2
import subprocess
# from base.contants import *

# file = os.path.abspath(__file__)
path_dir = os.path.dirname(__file__)

LOG_DIR = os.path.join(path_dir, f"../../auto_test_log")
# logger.info(f'LOG_DIR:{LOG_DIR}')

if not os.path.exists(LOG_DIR):
    # logger.info(f'os.mkdir:{LOG_DIR}')
    os.mkdir(LOG_DIR)


time_stamp = datetime.datetime.now().strftime("%Y%m%d%H%M")
filename = f'test_{time_stamp}.log'

# 获取日志文件的绝对路径
py_log_file = os.path.join(LOG_DIR, filename)

formatter2 = logging.Formatter(
    '[%(asctime)s]'
    '%(filename)s'
    '[Line:%(lineno)d]: '
    '%(message)s'
)

CH = logging.StreamHandler()
CH.setLevel(logging.DEBUG)
CH.setFormatter(formatter2)

global current_enable
current_enable = False

if current_enable:
    LOG = logging.getLogger(__file__)
    LOG.setLevel (logging.DEBUG)
    LOG.addHandler (CH)

_format =('[%(asctime)s][%(filename)s][%(funcName)s][%(lineno)s]'
' %(levelname)s: %(message)s')

# for differnt module, different log

def init_logger(loggername, file=None):
    logger = logging.getLogger(loggername)
    logger.setLevel(level=logging.DEBUG)
    if not logger.handlers and file:
        file_handler = logging.FileHandler(file, encoding="utf8")
        file_format = logging.Formatter(_format)
        file_handler.setFormatter(file_format)
        file_handler.setLevel(logging.DEBUG)
        logger.addHandler(file_handler)
        logger.addHandler(CH)
    return logger

print(f'py_log_file:{py_log_file}')
logger = init_logger('HELLO', py_log_file)
logger.info('hello')


def get_address_by_list(input_list):
    adress = None
    for item in input_list:
        if len(item) > 3:
            adress = item
            break
    return adress

def get_stack_begin_index(input_list):
    index = None
    for idx, line in enumerate(input_list):
        line = line.strip()
        # logger.info(f'line: {line}, idx: {idx}')
        if '>' in line and 'kd>' not in line:
            index = idx
            break
    return index

def is_number(obj):
    # 排除布尔类型（虽然bool是int的子类，但通常不视为数字）
    if 'ffff' in obj:
        return True
    else:
        return False

def get_storadapter_driver_and_address(input_line, result_dict, index):
    storadapter_adapter_driver = None
    storadapter_adapter_address = None

    if '\Driver' in input_line:
        split_list = input_line.split(' ')
        # logger.info(f'split_list: {split_list}')

        storadapter_adapter_driver = split_list[0]
        result_dict[f'storadapter_adapter{index}_driver'] = storadapter_adapter_driver
        logger.info(f'storadapter_adapter_driver: {storadapter_adapter_driver}')

        for idx, line in enumerate(split_list):
            if '' != line and idx > 0:
                result_dict[f'storadapter_adapter{index}_address'] = line
                logger.info(f'storadapter_adapter_address: {line}')
                break
    return storadapter_adapter_driver, storadapter_adapter_address

def parse_storadapter_driver_and_address(input_list, result_dict):
    # logger.info(f'input_list: {input_list}')
    get_storadapter_driver_and_address(input_list[0], result_dict, 1)
    if len(input_list) > 1:
        get_storadapter_driver_and_address(input_list[1], result_dict, 2)
    return


def update_dict_by_parse(cmd_output_list, item_list, result_dict):
    for item in item_list:
        value = get_list_text_line(cmd_output_list, f'{item}')
        value = value.replace(f'{item}:', '').strip()
        result_dict[f'{item}'] = value
    return

def get_Stack_Memory_Operation_Status(result):
    Stack_Memory_Operation_Status = 0
    for idx, line in enumerate(result):
        if 'nt!KeBugCheck' in line:
            # logger.info(f'line: {line}')
            last_line = result[idx + 1]
            last_line = last_line.lower()
            # logger.info(f'last_line: {last_line}')
            if 'nt!mi' in last_line or 'nt!kipagefault' in last_line or 'nt!mm' in last_line:
                Stack_Memory_Operation_Status = 1
    return Stack_Memory_Operation_Status

def get_list_first_valide_value(result):
    return_value = None
    for item in result:
        if '' != item and item != 0 and item != '0' and item != 1 and item != '1':
            return item
    return return_value

def get_list_text_line_after_line(input_list, first_key, second_key):
    text_line = ''
    if input_list is None:
        return text_line
    first_key_found = False
    for item in input_list:
        if first_key in item:
            first_key_found = True
        if first_key_found and second_key in item:
            text_line = item
    return text_line

def get_list_text_line_last_index(input_list, text):
    index = None
    if input_list is None:
        return index

    for idx, line in enumerate(input_list):
        if text in line:
            index = idx
    return index

def get_list_text_line_first_index(input_list, text):
    index = None
    if input_list is None:
        return index

    for idx, line in enumerate(input_list):
        if text in line:
            index = idx
            break
    return index

def get_list_text_line(result, text):
    text_line = ''
    if result is None:
        return text_line

    for item in result:
        if text in item:
            text_line = item
            break
    return text_line

def get_list_strip(result):
    text_lines = []
    if result is None:
        return text_lines

    for item in result:
        item = item.strip('\n')
        item = item.strip()
        if item:
            # logger.info(f'item:{item}')
            text_lines.append(f'{item}')
    return text_lines

def get_list_text_lines(result, text):
    text_lines = []
    if result is None:
        return text_lines
    for item in result:
        value = item.strip('\n')
        value = item.strip()
        if value and text in value:
            text_lines.append(value)
    return text_lines

def get_list_text_count(result, text):
    text_line = None
    count = 0
    if result is None:
        return count

    for item in result:
        if text in item:
            count = count + 1
    return count

# os.system
def cmd_excute(cmd, logger=None, outfile=None, errfile=None):
    if outfile is None and errfile is None:
        process = subprocess.Popen(
            cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
        logger.info(stdout.decode())
        # result = stdout.decode('utf-8').strip('\r\n')
        result = stdout
        errors = stderr
        return_code = process.returncode
        msg = result if not stderr else errors
        if logger:
            logger.info(cmd)
            logger.debug(return_code)
            if return_code != 0:
                logger.error(errors)

        return result, errors, return_code
    else:
        f_out = open(outfile, 'w')
        f_err = open(errfile, 'w')
        process = subprocess.Popen(
            cmd,
            shell=True,
            stdout=f_out,
            stderr=f_err)
        output, errors = process.communicate()
        return_code = process.returncode
        if logger:
            logger.info(cmd)
            logger.debug(return_code)
        if return_code != 0:
            logger.error(errors)

        return return_code



if __name__ == '__main__':
    obj = 'ffffe00167eea1c0'
    value = is_number(obj)
    print(value)
    # cmd = " ".join(args)
    # result, errors, return_code = cmd_excute(cmd)
    # logger.info(f'result:{result}, errors:{errors}, return_code:{return_code}')
    #
    # cmd = 'qqd'
    # result, errors, return_code = cmd_excute(cmd)
    # logger.info(f'result:{result}, errors:{errors}, return_code:{return_code}')
    pass

import os
import shutil
import sys
import logging
import time
import datetime
import re
from base.helper import *
from base import fileOP

def get_DPC_Timeout_Cout_cpu(input_list):
    # logger.info(f'input_list:{input_list}')
    cpu_num = None
    Period_line = input_list[2]
    logger.info(f'Period_line:{Period_line}')

    split_list = Period_line.split(' ')
    split_list = get_list_strip(split_list)
    Period = split_list[3]
    logger.info(f'Period:{Period}')

    DPC_Timeout_Cout_line = input_list[3]
    logger.info(f'DPC_Timeout_Cout_line:{DPC_Timeout_Cout_line}')

    split_list = DPC_Timeout_Cout_line.split(' ')
    split_list = get_list_strip(split_list)
    logger.info(f'split_list:{split_list}')
    DPC_Timeout_Cout = split_list[3]
    logger.info(f'DPC_Timeout_Cout:{DPC_Timeout_Cout}')

    if eval(DPC_Timeout_Cout) > eval(Period):
        colon_index = Period_line.index(':')
        cpu_num = Period_line[0:colon_index]
        logger.info(f'cpu_num:{cpu_num}')
    return cpu_num

def get_cpu_index(input_list):
    index = None
    for idx, line in enumerate(log_lines):
        if 'CPU Type' in line:
            index = idx + 1
    return index

if __name__ == '__main__':
    log_file = '112.txt'
    result_dict = {}
    with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
        log_lines = f.readlines()  # 列表形式存储每一行日志，保留换行符

    log_lines = get_list_strip(log_lines[1:])
    logger.info(f'log_lines:{log_lines}')

    index = get_cpu_index(log_lines)
    logger.info(f'index:{log_lines[index]}')

    cpu_group_list = log_lines[index:]
    # logger.info(f'cpu_group_list:{cpu_group_list}')

    len_cpu_group_list = len(cpu_group_list)
    logger.info(f'len_cpu_group_list:{len_cpu_group_list}')

    cpu_group_count = len_cpu_group_list/5
    logger.info(f'cpu_group_count:{cpu_group_count}')

    for idx in range(int(cpu_group_count)):
        logger.info(f'idx:{idx}')
        start_idx = idx * 5
        end_idx = (idx + 1) * 5
        tmp_group_list = cpu_group_list[start_idx:end_idx]
        cpu_num = get_DPC_Timeout_Cout_cpu(tmp_group_list)

        logger.info(f'cpu_num:{cpu_num}')

    for idx, line in enumerate(log_lines):
        if 'CPU Type' in line:
            flag = True
        if ':' in line and flag:
            cpu = get_DPC_Timeout_Cout_cpu(log_lines[idx: idx + 5])

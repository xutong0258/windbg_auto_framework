import json
from base import common
from base import fileOP
from base.helper import *
from base.componet import *
from base.AdvancedWinDbgInterface import *
from base.cell_command import *

def one_process_storage_5(dump_file, log_file):
    # start
    if not windbg.start(target=dump_file):
        return
    
    analyze_v_run(result_dict)

    storage_run(log_file, result_dict)

    command_his = windbg.get_total_cmd()

    # stop
    windbg.stop()
    return


def one_process_run(dump_file, log_file, path_dir):
    # start
    if not windbg.start(target=dump_file):
        return

    result_dict = {}
    try:
        # 1. Automatic
        logger.info(f'1.Automatic')
        command_dict = analyze_v_run(result_dict)

        # 2. Sysinfo
        logger.info(f'2.Sysinfo')
        system_info_run(log_file, result_dict)

        # 3. Current Thread
        logger.info(f'3.Current Thread')
        Current_Thread_run(log_file, result_dict)

        # 4. Process
        logger.info(f'4.Process')
        process_vm_run(log_file, result_dict)

        # 5. Storage
        logger.info(f'5.Storage')
        storage_run(log_file, result_dict)

        # 6. PnP
        logger.info(f'6.PnP')
        PnP_run(result_dict)

        # 7. ACPI
        BUGCHECK_CODE = result_dict.get('BUGCHECK_CODE', None)
        BSOD_Supcious_Driver = result_dict.get('BSOD_Supcious_Driver', None)
        logger.info(f'BSOD_Supcious_Driver: {BSOD_Supcious_Driver}')
        if BUGCHECK_CODE == '9f' and BSOD_Supcious_Driver and BSOD_Supcious_Driver == 'ACPI':
            logger.info(f'7.ACPI')
            ACPI_run(log_file, result_dict)

        # 8. NDIS
        BSOD_Supcious_Driver = result_dict.get('BSOD_Supcious_Driver', None)
        if BSOD_Supcious_Driver == 'NDIS Driver':
            logger.info(f'8.NDIS')
            ndis_run(result_dict)

        # 9. USB
        BSOD_Supcious_Device = result_dict.get('BSOD_Supcious_Device', None)
        if BSOD_Supcious_Device == 'USB':
            logger.info(f'9.USB')
            usb_run(log_file, result_dict)

        # 10. WHEA_0x124
        if BUGCHECK_CODE == '124':
            logger.info(f'10.WHEA_0x124')
            WHEA_0x124_run(log_file, result_dict)

        # 11. Power_0x9f_3
        if BUGCHECK_CODE == '9f' and BUGCHECK_P1 == '3':
            logger.info(f'11.Power_0x9f_3')
            Power_0x9f_3_run(log_file, result_dict)

        # 12. Power_0x9f_4
        if BUGCHECK_CODE == '9f' and BUGCHECK_P1 == '4':
            logger.info(f'12.Power_0x9f_4')
            Power_0x9f_4_run(result_dict)

        # 13. DPC_0x133
        if BUGCHECK_CODE == '133':
            BSOD_Supcious_Driver = result_dict['MODULE_NAME']
            result_dict['BSOD_Supcious_Driver'] = BSOD_Supcious_Driver
            dpc_run(log_file, result_dict)

        # 14. locks_0xE2
        if BUGCHECK_CODE == 'e2':
            logger.info(f'14.locks_0xE2')
            locks_run(result_dict)

        command_his, command_dict = windbg.get_total_cmd()
    finally:
        windbg.stop()

    common.dump_result_yaml(result_dict, command_his, command_dict, path_dir)
    return
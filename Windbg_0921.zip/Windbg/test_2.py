from base import fileOP
from base.helper import *

if __name__ == '__main__':
    log_file = '112.txt'
    cpu_num = fileOP.get_swd_DPCTimeout_CPU(None,log_file)
    logger.info(cpu_num)
    pass
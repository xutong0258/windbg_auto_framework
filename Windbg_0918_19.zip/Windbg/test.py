import os
import shutil
import sys
import logging
import time
import datetime
import re
from base.helper import *
from base import fileOP

if __name__ == '__main__':
    # 读取文件内容
    with open('11.txt', 'r') as file:
        file_content = file.readlines()

    file_content_new = []
    for idx, line in enumerate(file_content):
        line = line.strip()
        if line:
            file_content_new.append(line)
    # 执行解析
    logger.info(f'file_content_new: {file_content_new}')
    thread_contention_pairs,max_thread_name = fileOP.parse_locks_content(file_content_new)
    logger.info(f'thread_contention_pairs: {thread_contention_pairs}')
    logger.info(f'max_thread_name: {max_thread_name}')
# coding=utf-8

import json
import os
import shutil
import sys
import logging
import time
import datetime
import re
from base.helper import *
from base import fileOP
from base.contants import *

def parse_devstack(log_file_path, result_dict):
    # logger.info(f'log_file_path: {log_file_path}')

    start_text = f'kd> !devstack'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    # logger.info(f'blocked_device_Context: {result}')
    result_dict['blocked_device_Context'] = result

    # result = fileOP.parse_devstack_to_servicename(result)
    if result:
        line = get_list_text_line(result, 'ServiceName is')
        if line:
            result_dict['blocked_device_ServiceName'] = line

        line = get_list_text_line(result, 'DeviceInst is')
        if line:
            result_dict['blocked_device_DeviceInst'] = line

    if result:
        line = get_list_text_line(result[1:], '>')
        if line:
            blocked_device_DevExta_address = line.split(' ')[3]
            result_dict['blocked_device_DevExta_address'] = blocked_device_DevExta_address

    return result_dict

def parse_blocked_IRP_address(log_file, result_dict, blocked_IRP_address):
    blocked_device_Address = None
    start_text = f'kd> !irp {blocked_IRP_address}'
    end_text = f'kd>'
    result = fileOP.get_text_with_start_text_to_end(log_file, start_text, end_text)
    # logger.info(f'blocked_irp_context: {result}')
    if result:
        result_dict['blocked_irp_context'] = result

    for idx, line in enumerate(result):
        line = line.strip()
        # case 7
        if '\\Driver\\' in line and '>' in result[idx-2]:
            logger.info(f'line: {line}, idx: {idx}')
            blocked_irp_driver = get_driver(line)
            result_dict['blocked_irp_driver'] = blocked_irp_driver
            logger.info(f'blocked_irp_driver: {blocked_irp_driver}')

            # address, case:4.1
            split_list = result[idx-1].split(' ')
            if len(split_list) >=4:
                blocked_device_Address = split_list[3]
                logger.info(f'blocked_device_Address: {blocked_device_Address}')
                result_dict['blocked_device_Address'] = blocked_device_Address
            break

    return result_dict, blocked_device_Address

def parse_locks_thread_info(log_file, result_dict):
    blocked_IRP_address = None
    start_text = f'kd> !thread'
    end_text = f'kd>'
    result = fileOP.get_text_with_start_text_to_end(log_file, start_text, end_text)
    # logger.info(f'Locks_thread_context: {result}')
    if result:
        result_dict['Locks_thread_context'] = result

        for idx, line in enumerate(result):
            line = line.strip()
            if 'IRP List' in line:
                logger.info(f'IRP List: {line}')
                blocked_IRP_address = result[idx + 1].split(':')[0]
                logger.info(f'blocked_IRP_address: {blocked_IRP_address}')
                result_dict['blocked_IRP_address'] = blocked_IRP_address

    return result_dict, blocked_IRP_address

def parse_locks_info(log_file, result_dict):
    start_text = f'kd> !locks'
    end_text = f'kd>'
    result = fileOP.get_text_with_start_text_to_end(log_file, start_text, end_text)
    # logger.info(f'Locks_Context: {result}')
    if result:
        new_result = get_list_strip(result)
        result_dict['Locks_Context'] = new_result

    file_content_new = []
    for idx, line in enumerate(result):
        line = line.strip()
        if line:
            file_content_new.append(line)
    # 执行解析
    # logger.info(f'file_content_new: {file_content_new}')
    thread_contention_pairs,Locks_thread_Address = fileOP.parse_locks_content(file_content_new)
    logger.info(f'thread_contention_pairs: {thread_contention_pairs}')
    Locks_thread_Address = Locks_thread_Address.replace('-01<*>', '')
    logger.info(f'Locks_thread_Address: {Locks_thread_Address}')

    result_dict['Locks_thread_Address'] = Locks_thread_Address
    result_dict['blocked_thread_Address'] = Locks_thread_Address

    if Locks_thread_Address:
        result_dict['Locks_thread_Status'] = 1
    else:
        result_dict['Locks_thread_Status'] = 0

    return result_dict, Locks_thread_Address

def parse_process_vm_info(log_file, result_dict):
    start_text = f'kd> !VM'
    end_text = f'kd>'
    result = fileOP.get_text_with_start_text_to_end(log_file, start_text, end_text)
    # logger.info(f'VM_Context: {result}')
    if result:
        result_dict['VM_Context'] = result

    return result_dict

def parse_thread_info(log_file, result_dict):
    start_text = f'kd> !thread'
    end_text = f'kd>'
    result = fileOP.parse_text_with_start_end(log_file, start_text, end_text)
    # logger.info(f'thread: {result}')
    if result:
        result_dict['thread_Context'] = result

    start_text = f'kd> !running -it'
    result = fileOP.get_text_with_start_text_to_end(log_file, start_text)
    # logger.info(f'running -it: {result}')
    if result:
        result_dict['running_Context'] = result

    return result_dict

def parse_system_info(log_file, result_dict):
    start_text = f'kd> vertarget'
    end_text = f'kd>'
    result = fileOP.parse_text_with_start_end(log_file, start_text, end_text)
    if result:
        result_dict['vertarget_Context'] = result
        OS_Version_ID = NOT_FOUND
        for item in result:
            if 'Edition build lab' in item:
                OS_Version_ID = item

        result_dict['OS_Version_ID'] = OS_Version_ID

    # !sysinfo cpuinfo
    start_text = f'kd> !sysinfo cpuinfo'
    end_text = f'kd>'
    result = fileOP.parse_text_with_start_end(log_file, start_text, end_text)
    if result:
        result_dict['cpuinfo_Context'] = result

    # !sysinfo cpumicrocode
    start_text = f'kd> !sysinfo cpumicrocode'
    end_text = f'kd>'
    result = fileOP.parse_text_with_start_end(log_file, start_text, end_text)
    if result:
        result_dict['cpumicrocode_context'] = result

    # !sysinfo cpuspeed
    start_text = f'kd> !sysinfo cpuspeed'
    end_text = f'kd>'
    result = fileOP.parse_text_with_start_end(log_file, start_text, end_text)
    if result:
        result_dict['cpuspeed_context'] = result

        pattern = re.compile(r'CPUID:\s+(.*)')
        for item in result:
            if 'CPUID:' in item:
                # 查找所有匹配结果（返回捕获组内容的列表）
                CPUID = pattern.findall(item)
                logger.info(f'CPUID: {CPUID}')
                result_dict['CPUID'] = CPUID

    # !sysinfo smbios
    start_text = f'kd> !sysinfo smbios'
    start_index_offset = 4
    result = fileOP.get_text_with_start_text_with_offset(log_file, start_text, start_index_offset)
    if result:
        result_dict['kdlog_Context'] = result

    return result_dict

def parse_Sysinfo(log_file, results, result_yaml_file):
    # log_file = '02.log'
    patterns = {
        "vertarget_Context": r"vertarget_Context:\s*(\w+)",
        "OS Version ID": r"OS Version ID:\s*(\w+)",
        "cpuinfo_Context": r"cpuinfo_Context\s*(\w+)",
        "cpumicrocode_context": r"cpumicrocode_context\s*(\w+)",
        "cpuspeed_context": r"cpuspeed_context\s*(\w+)",
        "CPUID": r"CPUID\s*(\w+)",
        "CPUID": r"smbios_context\s*(\w+)",
    }
    results = fileOP.parse_file_by_pattern(log_file, patterns)

    # file_name = '02_Sysinfo.yaml'
    fileOP.dump_file(result_yaml_file, results)
    return results

def parse_amli_r(log_file_path, result_dict):
    # logger.info('parse_Power_0x9f_3_key_words')
    start_text = f'kd> !amli r'
    start_index_offset = 2
    result = fileOP.get_text_with_start_text_with_offset(log_file_path, start_text, start_index_offset)

    ACPI_Method_AMLPointer = ''
    new_result = []
    if result:
        for item in result:
            item = item.strip()
            if item != '':
                new_result.append(item)
            if 'Next AML Pointer:' in item:
                ACPI_Method_AMLPointer = item

    result_dict['ACPI_Method_Context'] = new_result
    result_dict['ACPI_Method_AMLPointer'] = ACPI_Method_AMLPointer

    return result_dict

def parse_ndiskd_netadapter(log_file_path, result_dict, Ndis_netadapter_address):
    # logger.info('parse_Power_0x9f_3_key_words')
    start_text = f'kd> !ndiskd.netadapter {Ndis_netadapter_address}'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    Ndis_netadapter1_address = result['Ndis_netadapter1_address']
    if Ndis_netadapter_address == Ndis_netadapter1_address:
        result_dict['NDIS_netadapter1_Context'] = result
    else:
        result_dict['NDIS_netadapter2_Context'] = result
    return result_dict

def parse_usb(log_file_path, result_dict):
    # logger.info('parse_Power_0x9f_3_key_words')
    start_text = f'kd> !usb_tree'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    result_dict['usb_tree_Context'] = result
    return result_dict

def parse_ndiskd_oid(log_file_path, result_dict):
    # logger.info('parse_Power_0x9f_3_key_words')
    start_text = f'kd> !ndiskd.oid'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    result_dict['NDIS_OID_Context'] = result

    Ndis_netadapter1_address = None
    Ndis_netadapter2_address = None

    text_lines = get_list_text_lines(result, 'NetAdapter')
    if text_lines:
        NDIS_OID_Pending_Status = 1
        text_line = text_lines[0].replace('NetAdapter', '').strip()
        temp_list = text_line.split('-')
        Ndis_netadapter1_address = temp_list[0]
        Ndis_netadapter1_name = temp_list[1]

        logger.info(f'NDIS_netadapter1_address: {Ndis_netadapter1_address}')
        logger.info(f'Ndis_netadapter1_name: {Ndis_netadapter1_name}')

        result_dict['Ndis_netadapter1_address'] = Ndis_netadapter1_address
        result_dict['Ndis_netadapter1_name'] = Ndis_netadapter1_name

        # 2
        text_line = text_lines[1].replace('NetAdapter', '').strip()
        temp_list = text_line.split('-')
        Ndis_netadapter2_address = temp_list[0]
        Ndis_netadapter2_name = temp_list[1]

        logger.info(f'Ndis_netadapter2_address: {Ndis_netadapter2_address}')
        logger.info(f'Ndis_netadapter2_name: {Ndis_netadapter2_name}')

        result_dict['Ndis_netadapter2_address'] = Ndis_netadapter2_address
        result_dict['Ndis_netadapter2_name'] = Ndis_netadapter2_name
    else:
        NDIS_OID_Pending_Status = 0

    result_dict['NDIS_OID_Pending_Status'] = NDIS_OID_Pending_Status

    return result_dict, Ndis_netadapter1_address, Ndis_netadapter2_address

def parse_analyze_v(log_file):
    result_dict = {}
    # log_file = '01.log'
    str_result = fileOP.extract_bugcheck_analysis(log_file)
    # logger.info(str_result)

    result_dict['Bugcheck_Analysis'] = str_result

    patterns = {
        "BUGCHECK_CODE": r"BUGCHECK_CODE:\s*(\w+)",  # 匹配BUGCHECK_CODE后面的值
        "BUGCHECK_P1": r"BUGCHECK_P1:\s*(\w+)",  # 匹配BUGCHECK_P1后面的值
        "BUGCHECK_P2": r"BUGCHECK_P2:\s*(\w+)" ,
        "BUGCHECK_P3": r"BUGCHECK_P3:\s*(\w+)",  # 匹配BUGCHECK_P1后面的值
        "BUGCHECK_P4": r"BUGCHECK_P4:\s*(\w+)",
        "FAILURE_BUCKET_ID": r"FAILURE_BUCKET_ID:\s*(\w+)",
        "DISK_HARDWARE_ERROR_Status": r"DISK_HARDWARE_ERROR_Status:\s*(\w+)",
        "Moduel_Name": r"MODULE_NAME:\s*(\w+)",
    }
    results_tmp = fileOP.parse_file_by_pattern(log_file, patterns)
    # logger.info(f'results_tmp:{results_tmp}')
    result_dict.update(results_tmp)

    # Trap_Frame_Context
    result_str, content_flag = fileOP.extract_TRAP_FRAME_segment(log_file)
    # logger.info(f'result_str: {result_str}')

    result_dict.update({'Trap_Frame_Context': f'{result_str}'})
    if content_flag:
        Conext_Memory_Corruption_Status = 1
    else:
        Conext_Memory_Corruption_Status = 0

    result_dict.update({'Conext_Memory_Corruption_Status': Conext_Memory_Corruption_Status})

    # Stack_Text
    result_str, Stack_Memory_Operation_Status = fileOP.extract_Stack_Text_segment(log_file)
    result_dict['Stack_Text'] = result_str

    result_dict.update({'Stack_Memory_Operation_Status': Stack_Memory_Operation_Status})

    Memory_Status_Abnormal = 0
    if Conext_Memory_Corruption_Status or Stack_Memory_Operation_Status:
        Memory_Status_Abnormal = 1

    result_dict.update({'Memory_Status_Abnormal': Memory_Status_Abnormal})

    # other
    result_dict.update({'Disk_Status_Abnormal': 0})

    # fileOP.dump_file(result_yaml_file, result_dict)
    return result_dict

def parse_thread(log_file_path, result_yaml_file, result_dict):
    logger.info('parse_thread begin')
    start_text = f'0: kd> !thread'
    end_text = f'0: kd>'
    result = fileOP.parse_text_with_start_end(log_file_path, start_text, end_text)
    result_dict['thread_Context'] = result

    # running_Context
    start_text = f'0: kd> !running -it'
    end_text = f': kd>'
    result = fileOP.parse_text_with_start_end(log_file_path, start_text, end_text)
    result_dict['running_Context'] = result

    # last dump
    fileOP.dump_file(result_yaml_file, result_dict)
    logger.info('parse_thread end')
    return result_dict

def parse_process(log_file_path, result_yaml_file, result_dict):
    logger.info('parse_process begin')
    start_text = f'0: kd> !VM'
    end_text = f': kd>'
    result = fileOP.parse_text_with_start_end(log_file_path, start_text, end_text)
    result_dict['VM_Context'] = result

    # last dump
    fileOP.dump_file(result_yaml_file, result_dict)
    logger.info('parse_process end')
    return result_dict

def parse_lock(log_file_path, result_yaml_file, result_dict):
    logger.info('parse_lock begin')
    start_text = f'0: kd> !VM'
    end_text = f': kd>'
    result = fileOP.parse_text_with_start_end(log_file_path, start_text, end_text)
    result_dict['VM_Context'] = result

    # last dump
    fileOP.dump_file(result_yaml_file, result_dict)
    logger.info('parse_lock end')
    return result_dict


def get_driver(input_str):
    # 定义要匹配的前缀
    prefix = '\\Driver\\'

    # 检查字符串是否包含目标前缀
    if prefix in input_str:
        # 找到前缀结束的位置
        prefix_end_index = input_str.find(prefix) + len(prefix)

        # 从 prefix 结束位置开始，截取到制表符(\t)出现的位置
        # 因为原字符串中 igfx 后面是制表符分隔
        tab_index = input_str.find('\t', prefix_end_index)

        # 提取目标字段
        if tab_index != -1:
            target_field = input_str[prefix_end_index:tab_index]
            # logger.info(f"提取到的字段: {target_field}")  # 输出: igfx
        else:
            # 如果没有制表符，直接取剩余全部内容
            target_field = input_str[prefix_end_index:]
            # logger.info(f"提取到的字段: {target_field}")
    else:
        logger.info(f"字符串中不包含前缀: {prefix}")

    return target_field

def parse_amli_lc(log_file_path, result_dict):
    # logger.info('parse_Power_0x9f_3_key_words')
    start_text = f'!amli lc'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    # logger.info(f'result:{result}')

    ACPI_Method_Address = ''
    ACPI_Method_Object = ''
    ACPI_Method_Status = 0
    for item in result:
        if 'Ctxt=' in item:
            ACPI_Method_Address = re.findall(r'Ctxt=(.*?),', item)
            ACPI_Method_Status = 1
        if 'Obj=' in item:
            prefix = "Obj="
            # 查找前缀在字符串中的位置
            prefix_index = item.find(prefix)
            if prefix_index != -1:
                # 提取前缀后面的所有内容（从prefix结束位置开始截取）
                ACPI_Method_Object = item[prefix_index + len(prefix):]
                ACPI_Method_Object = ACPI_Method_Object.strip()
                logger.info(f"提取到的Obj字段值: {ACPI_Method_Object}")  # 输出: _SB,hello
            else:
                logger.info(f"字符串中未找到 '{prefix}'")
            ACPI_Method_Status = 1

    result_dict['ACPI_Method_Status'] = ACPI_Method_Status
    result_dict['ACPI_Method_Address'] = ACPI_Method_Address
    result_dict['ACPI_Method_Object'] = ACPI_Method_Object

    return result_dict

def parse_storage(log_file_path, result_dict):
    start_text = f'kd> !storagekd.storclass'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    logger.info(f'storclass: {result}')

    result_dict['Storclass_FDO1_Context'] = result

    return result_dict

def parse_storadapter_storunit1_address(log_file_path, result_dict, storadapter_storunit1_address):
    start_text = f'kd> !storunit {storadapter_storunit1_address}'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    # logger.info(f'storclass: {result}')
    result_dict['storadapter_storunit1_context'] = result
    return result_dict

def parse_storadapter_storunit2_address(log_file_path, result_dict, storadapter_storunit2_address):
    start_text = f'kd> !storunit {storadapter_storunit2_address}'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    # logger.info(f'storclass: {result}')
    result_dict['storadapter_storunit2_context'] = result
    return result_dict

def parse_storadapter_storadapter_adapter1_address(log_file_path, result_dict, storadapter_adapter1_address):

    start_text = f'kd> !storadapter {storadapter_adapter1_address}'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    # logger.info(f'storclass: {result}')
    result_dict['storadapter_adapter1_Context'] = result

    count = get_list_text_count(result, 'SurpriseRemoval')
    if count:
        storadapter_adapter1_SurpriseRemoval_Status = 1
    else:
        storadapter_adapter1_SurpriseRemoval_Status = 0
    result_dict['storadapter_adapter1_SurpriseRemoval_Status'] = storadapter_adapter1_SurpriseRemoval_Status

    lines = get_list_text_lines(result, 'SurpriseRemoval')
    for idx, line in enumerate(lines):
        if idx == 0:
            split_list = line.split(' ')
            logger.info(f'split_list:{split_list}')
            storadapter_storunit1_address = get_list_first_valide_value(split_list)
            logger.info(f'storadapter_storunit1_address:{storadapter_storunit1_address}')
            result_dict['storadapter_storunit1_address'] = storadapter_storunit1_address
        if idx == 1:
            split_list = line.split(' ')
            logger.info(f'split_list:{split_list}')
            storadapter_storunit2_address = get_list_first_valide_value(split_list)
            logger.info(f'storadapter_storunit2_address:{storadapter_storunit2_address}')
            result_dict['storadapter_storunit2_address'] = storadapter_storunit2_address
    return result_dict

def parse_storadapter(log_file_path, result_dict):
    start_text = f'kd> !storadapter'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    # logger.info(f'storclass: {result}')

    for idx, line in enumerate(result):
        if 'Driver' in line and 'Object' in line:
            split_list = result[idx + 2].split(' ')
            logger.info(f'split_list: {split_list}')

            storadapter_adapter1_driver = split_list[0]
            logger.info(f'storadapter_adapter1_driver: {storadapter_adapter1_driver}')
            result_dict['storadapter_adapter1_driver'] = storadapter_adapter1_driver

            for idx, line in enumerate(split_list):
                if '' != line and idx > 0:
                    result_dict['storadapter_adapter1_address'] = line
                    logger.info(f'storadapter_adapter1_address: {line}')
                    break

    return result_dict

def parse_storagekd_storclass(log_file_path, result_dict):
    start_text = f'kd> !storagekd.storclass'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    # logger.info(f'storclass: {result}')

    result_dict['Storclass_FDO1_Context'] = result

    # need logic
    count = get_list_text_count(result, 'Retried')
    if count > 4:
        Storclass_FDO1_Failed_Requests_Status = 1
    else:
        Storclass_FDO1_Failed_Requests_Status = 0

    result_dict['Storclass_FDO1_Failed_Requests_Status'] = Storclass_FDO1_Failed_Requests_Status

    return result_dict

def parse_PnP(log_file_path, result_dict):
    start_text = f'!devnode 1'
    end_text = 'kd> '
    result = fileOP.parse_text_with_start_end(log_file_path, start_text, end_text)
    # logger.info(f'storclass: {result}')
    count = get_list_text_count(result, 'Pending Removal')
    if count:
        new_result = get_list_strip(result)
        logger.info(f'new_result: {new_result}')
        result_dict['Pending_Removal_Context'] = new_result

    return result_dict

def parse_storclass_sub(result_list, result_dict):
    for idx, line in enumerate(result_list):
        if 'FDO' in line and '# Device ID' in line:
            Storclass_FDO1_address = result_list[idx + 2]
            logger.info(f'Storclass_FDO1: {Storclass_FDO1_address}')
            split_list = Storclass_FDO1_address.split(' ')
            logger.info(f'split_list: {split_list}')

            Storclass_FDO1_address = split_list[0]
            Storclass_FDO1_DeviceID = split_list[5]
            logger.info(f'Storclass_FDO1_DeviceID: {Storclass_FDO1_DeviceID}')

            logger.info(f'Storclass_FDO1_address: {Storclass_FDO1_address}')
            logger.info(f'Storclass_FDO1_DeviceID: {Storclass_FDO1_DeviceID}')

            result_dict['Storclass_FDO1_address'] = Storclass_FDO1_address
            result_dict['Storclass_FDO1_DeviceID'] = Storclass_FDO1_DeviceID

    # result_dict['NDIS_OID_Context'] = result

    return result_dict

def parse_storclass(log_file_path, result_dict):
    start_text = f'kd> !storclass'
    result_list = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    # logger.info(f'storclass: {result_list}')
    if result_list:
        result_dict = parse_storclass_sub(result_list, result_dict)

    # result_dict['NDIS_OID_Context'] = result

    return result_dict

def parse_devstack(log_file_path, result_dict):
    start_text = f'kd> !devstack'
    end_text = f'kd> '
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text, end_text)
    # logger.info(f'storclass: {result}')
    result_dict['blocked_device_Context'] = result

    line = get_list_text_line(result, 'ServiceName is')
    if line:
        result_dict['blocked_device_ServiceName'] = line

    line = get_list_text_line(result, 'DeviceInst is')
    if line:
        result_dict['blocked_device_DeviceInst'] = line

    return result_dict

def parse_devstack(log_file_path, result_dict):
    start_text = f'kd> !devstack'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    # logger.info(f'storclass: {result}')
    result_dict['blocked_device_Context'] = result

    line = get_list_text_line(result, 'ServiceName is')
    if line:
        result_dict['blocked_device_ServiceName'] = line

    line = get_list_text_line(result, 'DeviceInst is')
    if line:
        result_dict['blocked_device_DeviceInst'] = line

    return result_dict

def parse_Power_irp_blocked_irp_Address(log_file_path, result_dict):
    start_text = f'kd> !irp'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    # logger.info(f'storclass: {result}')
    result_dict['blocked_irp_context'] = result

    line = get_list_text_line(result, '\\Driver\\')
    if line:
        blocked_irp_driver = get_driver(line)
        blocked_irp_driver = blocked_irp_driver.replace('\\', '')
        result_dict['blocked_irp_driver'] = blocked_irp_driver
        logger.info(f'blocked_irp_driver: {blocked_irp_driver}')

    return result_dict

def parse_powertriage(log_file_path, result_dict):
    logger.info(f'result_dict type: {type(result_dict)}')

    # Power Action
    start_text = f'Power Action:'
    start_index_offset = 6
    end_text = f'State.:'
    result = fileOP.get_text_with_start_text_with_offset(log_file_path, start_text, start_index_offset)

    tmp_list = []

    line = get_list_text_line(result, 'PopAction :')
    logger.info(f'line: {line}')
    logger.info(f'line type: {type(line)}')
    if line:
        result_dict['System_State_Context'] = line

    # PCI
    start_text = f'+  PCI\\VEN_'
    end_text = f'+  USB\\'
    result = fileOP.parse_text_with_start_end(log_file_path, start_text, end_text)

    text_lines = get_list_strip(result)
    if text_lines:
        result_dict['Device_State_Context'] = text_lines

    return result_dict

def parse_devstack(log_file_path, result_dict):
    start_text = f'kd> !devstack'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    # logger.info(f'storclass: {result}')
    result_dict['blocked_device_Context'] = result

    line = get_list_text_line(result, 'ServiceName is')
    if line:
        result_dict['blocked_device_ServiceName'] = line

    line = get_list_text_line(result, 'DeviceInst is')
    if line:
        result_dict['blocked_device_DeviceInst'] = line

    line = get_list_text_line(result[1:], '>')
    logger.info(f'line: {line}')
    if line:
         split_list = line.split(' ')
         logger.info(f'split_list: {split_list}')

         new_list = get_list_strip(split_list)
         logger.info(f'new_list: {new_list}')

         blocked_device_DevExta_address = new_list[3]
         logger.info(f'blocked_device_DevExta_address: {blocked_device_DevExta_address}')
         result_dict['blocked_device_DevExta_address'] = blocked_device_DevExta_address
    return result_dict


def parse_errrec_WHEA_ERROR_RECORD_Address(log_file_path, result_dict):
    # Power Action
    start_text = f'kd> !errrec'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    result_dict['WHEA_ERROR_RECORD_Context'] = result

    WHEA_ERROR_RECORD_Type = get_list_text_line(result, 'Notify Type')
    if WHEA_ERROR_RECORD_Type:
        result_dict['WHEA_ERROR_RECORD_Type'] = WHEA_ERROR_RECORD_Type

        result_dict['BSOD_Supcious_Device'] = WHEA_ERROR_RECORD_Type

    return result_dict

def parse_WHEA(log_file_path, result_dict):
    # Power Action
    start_text = f'kd> !WHEA'
    result = fileOP.get_text_with_start_text_to_end(log_file_path, start_text)
    result_dict['WHEA_Context'] = result

    return result_dict
if __name__ == '__main__':
    logger.info('common hello')
    pass

# coding=utf-8

import json
from base import common
from base import fileOP
from base.helper import *
from base.contants import *
from base.AdvancedWinDbgInterface import *
from base.cell_command import *


def PnP_run(log_file, result_dict):
    cmd = "!pnptriage"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # time.sleep(TIME_OUT)

    cmd = "!devnode 1"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)

    cmd = "!devnode 0 1"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)

    result_dict = common.parse_PnP(log_file, result_dict)
    return result_dict

def storage_run(log_file, result_dict):
    cmd = ".load storagekd "
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # time.sleep(TIME_OUT)

    cmd = "!storclass"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    time.sleep(5)

    result_dict = common.parse_storclass(log_file, result_dict)

    Storclass_FDO1_address = result_dict.get('Storclass_FDO1_address', None)
    if Storclass_FDO1_address:
        cmd = f"!storagekd.storclass {Storclass_FDO1_address} 2"
        logger.info(f'cmd: {cmd}')
        result = windbg.execute_command(cmd, timeout=15)

        result_dict = common.parse_storagekd_storclass(log_file, result_dict)

    # storadapter
    cmd = "!storadapter"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)

    result_dict = common.parse_storadapter(log_file, result_dict)

    # !storadapter storadapter_adapter1_address
    storadapter_adapter1_address = result_dict.get('storadapter_adapter1_address', None)
    if storadapter_adapter1_address:
        cmd = f"!storadapter {storadapter_adapter1_address}"
        logger.info(f'cmd: {cmd}')
        result = windbg.execute_command(cmd, timeout=15)
        result_dict = common.parse_storadapter_storadapter_adapter1_address(log_file, result_dict, storadapter_adapter1_address)

    storadapter_storunit1_address = result_dict.get('storadapter_storunit1_address', None)
    if storadapter_storunit1_address:
        cmd = f"!storunit {storadapter_storunit1_address}"
        logger.info(f'cmd: {cmd}')
        result = windbg.execute_command(cmd, timeout=15)
        result_dict = common.parse_storadapter_storunit1_address(log_file, result_dict, storadapter_storunit1_address)

    storadapter_storunit2_address = result_dict.get('storadapter_storunit2_address', None)
    if storadapter_storunit2_address:
        cmd = f"!storunit {storadapter_storunit2_address}"
        logger.info(f'cmd: {cmd}')
        result = windbg.execute_command(cmd, timeout=15)
        result_dict = common.parse_storadapter_storunit2_address(log_file, result_dict, storadapter_storunit2_address)

    DISK_HARDWARE_ERROR_Status = result_dict.get('DISK_HARDWARE_ERROR_Status', None)
    storadapter_adapter1_SurpriseRemoval_Status = result_dict.get('storadapter_adapter1_SurpriseRemoval_Status', None)
    Storclass_FDO1_Failed_Requests_Status = result_dict.get('Storclass_FDO1_Failed_Requests_Status', None)
    storadapter_storunit1_Outstanding_IRP_Status = result_dict.get('storadapter_storunit1_Outstanding_IRP_Status', None)

    check_point = False
    if DISK_HARDWARE_ERROR_Status and DISK_HARDWARE_ERROR_Status == 1:
        check_point = True
    if storadapter_adapter1_SurpriseRemoval_Status and storadapter_adapter1_SurpriseRemoval_Status == 1:
        check_point = True
    if Storclass_FDO1_Failed_Requests_Status and Storclass_FDO1_Failed_Requests_Status == 1:
        check_point = True
    if storadapter_storunit1_Outstanding_IRP_Status and storadapter_storunit1_Outstanding_IRP_Status == 1:
        check_point = True

    Disk_Status_Abnormal = 0
    if check_point:
        Disk_Status_Abnormal = 1
    result_dict['Disk_Status_Abnormal'] = Disk_Status_Abnormal
    return result_dict

def usb_run(log_file, result_dict):
    cmd = ".load usb3kd"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # time.sleep(TIME_OUT)

    cmd = "!usb_tree"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # time.sleep(TIME_OUT)

    result_dict, Ndis_netadapter1_address = common.parse_ndiskd_oid(log_file, result_dict)

    return result_dict

def ndis_run(log_file_path, result_dict):
    cmd = ".load ndiskd"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # time.sleep(TIME_OUT)

    cmd = "!ndiskd.oid"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # time.sleep(TIME_OUT)

    result_dict, Ndis_netadapter1_address, Ndis_netadapter2_address = common.parse_ndiskd_oid(log_file_path, result_dict)

    cmd = f"!ndiskd.netadapter {Ndis_netadapter1_address}"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # time.sleep(TIME_OUT)

    result_dict = common.parse_ndiskd_netadapter(log_file_path, result_dict, Ndis_netadapter1_address)

    # Ndis_netadapter2_address
    cmd = f"!ndiskd.netadapter {Ndis_netadapter2_address}"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # time.sleep(TIME_OUT)

    result_dict = common.parse_ndiskd_netadapter(log_file_path, result_dict, Ndis_netadapter1_address)
    return result_dict

def locks_run(log_file, result_dict):
    result_dict, blocked_thread_Address = locks(log_file, result_dict)

    logger.info(f'blocked_thread_Address: {blocked_thread_Address}')

    result_dict, blocked_IRP_address = thread_blocked_thread_Address(log_file, result_dict, blocked_thread_Address)

    logger.info(f'blocked_IRP_address: {blocked_IRP_address}')

    blocked_device_Address = None
    if blocked_IRP_address:
        result_dict, blocked_device_Address = irp_blocked_IRP_address(log_file, result_dict, blocked_IRP_address)

        logger.info(f'blocked_device_Address: {blocked_device_Address}')

    if blocked_device_Address:
        result_dict = devstack_blocked_device_Address(log_file, result_dict, blocked_device_Address)

        blocked_irp_driver = result_dict['blocked_irp_driver']

        # must
        result_dict['BSOD_Supcious_Driver'] = blocked_irp_driver

        blocked_device_ServiceName = result_dict['blocked_device_ServiceName']
        blocked_device_DeviceInst = result_dict['blocked_device_DeviceInst']
        result_dict['BSOD_Supcious_Device'] = f'{blocked_device_ServiceName} {blocked_device_DeviceInst}'

    return result_dict

def process_vm_run(log_file, result_dict):
    cmd = "!VM"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # time.sleep(15)

    result_dict = common.parse_process_vm_info(log_file, result_dict)

    return result_dict

def thread_run(log_file, result_dict):
    cmd = "!thread"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # # time.sleep(15)

    cmd = "!running -it"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # # time.sleep(15)

    result_dict = common.parse_thread_info(log_file, result_dict)

    return result_dict

def Current_Thread_run(log_file, result_dict):
    cmd = "!thread"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # # time.sleep(15)

    cmd = "!running -it"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # # time.sleep(15)

    result_dict = common.parse_thread_info(log_file, result_dict)

    return result_dict

def system_info_run(log_file, result_dict):
    cmd = "vertarget"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # # time.sleep(TIME_OUT)

    cmd = "!sysinfo cpuinfo"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)

    cmd = "!sysinfo cpumicrocode"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)

    cmd = "!sysinfo cpuspeed"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)

    cmd = "!sysinfo smbios"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)

    # cmd = ".logclose"
    # logger.info(f'cmd: {cmd}')
    # result = windbg.execute_command(cmd, timeout=15)
    
    result_dict = common.parse_system_info(log_file, result_dict)
    return result_dict

def WHEA_0x124_run(log_file, result_dict):
    # Power_0x9f_3
    WHEA_ERROR_RECORD_Address = result_dict['BUGCHECK_P2']

    # errrec WHEA_ERROR_RECORD_Address
    cmd = f"!errrec {WHEA_ERROR_RECORD_Address}"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # time.sleep(15)

    result_dict = common.parse_errrec_WHEA_ERROR_RECORD_Address(log_file, result_dict)

    # !WHEA
    cmd = f"!WHEA"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # time.sleep(15)

    result_dict = common.parse_WHEA(log_file, result_dict)

    return result_dict

def Power_0x9f_3_run(log_file, result_dict):
    # Power_0x9f_3
    blocked_device_Address = result_dict['BUGCHECK_P2']
    blocked_irp_Address = result_dict['BUGCHECK_P4']

    result_dict = devstack_blocked_device_Address(log_file, result_dict, blocked_device_Address)

    # !irp blocked_irp_Address
    result_dict, blocked_device_Address = irp_blocked_IRP_address(log_file, result_dict, blocked_irp_Address)

    # !powertriage
    result_dict = powertriage(log_file, result_dict)
    return result_dict

def Power_0x9f_4_run(log_file, result_dict):
    Bugcheck_P3 = result_dict['BUGCHECK_P3']
    blocked_thread_Address = Bugcheck_P3
    result_dict['blocked_thread_Address'] = blocked_thread_Address

    # !thread blocked_thread_Address
    result_dict, blocked_IRP_address = thread_blocked_thread_Address(log_file, result_dict, blocked_thread_Address)

    logger.info(f'blocked_IRP_address: {blocked_IRP_address}')

    blocked_device_Address = None

    # !irp blocked_IRP_address
    if blocked_IRP_address:
        result_dict, blocked_device_Address = irp_blocked_IRP_address(log_file, result_dict, blocked_IRP_address)

    logger.info(f'blocked_device_Address: {blocked_device_Address}')
    # !devstack blocked_device_Address
    if blocked_device_Address:
        result_dict = devstack_blocked_device_Address(log_file, result_dict, blocked_device_Address)

    result_dict = powertriage(log_file, result_dict)

    return result_dict

def ACPI_run(log_file, result_dict):
    # ACPI
    result_dict = amli_lc_ACPI_Method_Address(log_file, result_dict)

    # cmd = f"!amli lc"
    # logger.info(f'cmd: {cmd}')
    # result = windbg.execute_command(cmd, timeout=15)
    # # time.sleep(15)
    #
    # result_dict = common.parse_amli_lc(log_file, result_dict)

    ACPI_Method_Status = result_dict['ACPI_Method_Status']

    if ACPI_Method_Status == 1:
        result_dict = amli_r_ACPI_Method_Address(log_file, result_dict)

        # ACPI_Method_Address = result_dict['ACPI_Method_Address']
        # cmd = f"!amli r {ACPI_Method_Address}"
        # logger.info(f'cmd: {cmd}')
        # result = windbg.execute_command(cmd, timeout=15)
        # # time.sleep(15)
        #
        # result_dict = common.parse_amli_r(log_file, result_dict)
    return result_dict


if __name__ == '__main__':
    # cmd = " ".join(args)
    # result, errors, return_code = cmd_excute(cmd)
    # logger.info(f'result:{result}, errors:{errors}, return_code:{return_code}')
    #
    # cmd = 'qqd'
    # result, errors, return_code = cmd_excute(cmd)
    # logger.info(f'result:{result}, errors:{errors}, return_code:{return_code}')
    pass

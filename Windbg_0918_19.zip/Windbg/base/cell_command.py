# coding=utf-8

import json
import os
import shutil
import sys
import logging
import time
import datetime
import re
import subprocess
from base.contants import *
from base.helper import *
from base import common

def analyze_v_run(log_file):
    # logger.info(f'analyze_v_run begin')

    # time.sleep(3)  # 等待初始化
    cmd = "!analyze  -v"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    time.sleep(30)

    result_dict = common.parse_analyze_v(log_file)

    # logger.info(f'analyze_v_run end')
    return result_dict

def thread_blocked_thread_Address(log_file, result_dict, blocked_thread_Address):
    cmd = f"!thread {blocked_thread_Address}"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # time.sleep(TIME_OUT_10)

    result_dict, blocked_IRP_address = common.parse_locks_thread_info(log_file, result_dict)
    return result_dict, blocked_IRP_address

def irp_blocked_IRP_address(log_file, result_dict, blocked_IRP_address):
    cmd = f"!irp {blocked_IRP_address}"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    time.sleep(TIME_OUT)

    result_dict, blocked_device_Address = common.parse_blocked_IRP_address(log_file, result_dict, blocked_IRP_address)

    return result_dict, blocked_device_Address

def devstack_blocked_device_Address(log_file, result_dict, blocked_device_Address):
    # !devstack blocked_device_Address
    cmd = f"!devstack {blocked_device_Address}"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    time.sleep(10)

    result_dict = common.parse_devstack(log_file, result_dict)
    return result_dict

def powertriage(log_file, result_dict):
    logger.info(f'result_dict type: {type(result_dict)}')

    # !powertriage
    cmd = f"!powertriage"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    time.sleep(15)

    result_dict = common.parse_powertriage(log_file, result_dict)

    blocked_irp_driver = result_dict['blocked_irp_driver']

    result_dict['BSOD_Supcious_Driver'] = blocked_irp_driver

    blocked_device_DeviceInst = result_dict['blocked_device_DeviceInst']
    result_dict['BSOD_Supcious_Device'] = blocked_device_DeviceInst
    return result_dict

def amli_r_ACPI_Method_Address(log_file, result_dict):
    ACPI_Method_Address = result_dict['ACPI_Method_Address']
    cmd = f"!amli r {ACPI_Method_Address}"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    # time.sleep(15)

    result_dict = common.parse_amli_r(log_file, result_dict)
    return result_dict

def amli_lc_ACPI_Method_Address(log_file, result_dict):
    cmd = f"!amli lc"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    time.sleep(10)

    result_dict = common.parse_amli_lc(log_file, result_dict)
    return result_dict

def locks(log_file, result_dict):
    cmd = "!locks"
    logger.info(f'cmd: {cmd}')
    result = windbg.execute_command(cmd, timeout=15)
    time.sleep(TIME_OUT_10)

    result_dict, blocked_thread_Address = common.parse_locks_info(log_file, result_dict)

    return result_dict, blocked_thread_Address

if __name__ == '__main__':
    # cmd = " ".join(args)
    # result, errors, return_code = cmd_excute(cmd)
    # logger.info(f'result:{result}, errors:{errors}, return_code:{return_code}')
    #
    # cmd = 'qqd'
    # result, errors, return_code = cmd_excute(cmd)
    # logger.info(f'result:{result}, errors:{errors}, return_code:{return_code}')
    pass

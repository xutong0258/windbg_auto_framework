# coding=utf-8

import yaml
import json
import os
import platform
import re
from base.helper import *
from base.contants import *


def parse_locks_content(log_lines):
    thread_contention_pairs = {}
    max_count = 0
    max_thread_name = None
    for idx, line in enumerate(log_lines):
        if 'Contention Count =' in line:
            # logger.info(f'line {line}')
            Contention_Count = line.split('Contention Count =')[1]
            if 'Threads:' in log_lines[idx+2]:
                thread_idx = idx+2
            else:
                thread_idx = idx + 1
            thread = log_lines[thread_idx]
            # logger.info(f'thread: {thread}')
            thread = thread.split('Threads:')[1]
            thread_contention_pairs[thread] = Contention_Count

            if int(Contention_Count) > max_count:
                max_count = int(Contention_Count)
                max_thread_name = thread

    return thread_contention_pairs, max_thread_name

def get_text_with_start_text_to_end(log_file_path, start_text, end_text='kd>'):
    logger.info(f'log_file_path: {log_file_path}')
    try:
        # 1. 读取日志文件内容（按行读取，保留原始格式）
        with open(log_file_path, 'r', encoding='utf-8', errors='ignore') as f:
            log_lines = f.readlines()  # 列表形式存储每一行日志，保留换行符

        # logger.info(f'log_lines: {log_lines}')
        # 2. 定位目标片段的起始行（包含"!devstack"的首行，即命令行起始）
        start_idx = None
        for idx, line in enumerate(log_lines):
            if start_text in line:  # 匹配起始标记
                start_idx = idx
                # logger.info(f'start_idx: {start_idx}')
                break
        if start_idx is None:
            logger.info(f"❌ 未在日志中找到起始标记:{start_text}")
            return None

        # 3. 定位目标片段的结束行（包含"ServiceName is"的行）
        end_idx = None
        # 从起始行之后开始查找，避免跨片段匹配
        for idx, line in enumerate(log_lines[start_idx+1:]):
            if end_text in line:
                end_idx = start_idx + idx  # 转换为全局索引
                break
        if end_idx is None:
            target_segment = log_lines[start_idx:]
        else:
            target_segment = log_lines[start_idx:end_idx + 1]
        # logger.info(f'target_segment:\n{target_segment}')
        final_list = list()
        for item in target_segment:
            item = item.strip()
            if item:
                final_list.append(item)
        return final_list

    except FileNotFoundError:
        logger.info(f"❌ 日志文件不存在：{log_file_path}，请检查文件路径是否正确")
        return None
    except Exception as e:
        logger.info(f"❌ 解析过程中发生错误：{str(e)}")
        return None

def get_text_with_start_text_with_offset(log_file_path, start_text, start_index_offset=0):
    """
    解析日志文件中从!devstack开始到ServiceName is结束的目标片段
    :param log_file_path: 日志文件路径（如level_2_log.txt）
    :return: 目标解析片段（字符串格式），若解析失败返回None
    """
    # logger.info('parse_text_with_start_end')
    start_idx = None
    try:
        # 1. 读取日志文件内容（按行读取，保留原始格式）
        with open(log_file_path, 'r', encoding='utf-8') as f:
            log_lines = f.readlines()  # 列表形式存储每一行日志，保留换行符

        # 2. 定位目标片段的起始行（包含"!devstack"的首行，即命令行起始）
        for idx, line in enumerate(log_lines):
            if start_text in line:  # 匹配起始标记
                start_idx = idx
                # logger.info(f'start_idx: {start_idx}')
                break
        if start_idx is None:
            logger.info(f"❌ 未在日志中找到起始标记:{start_text}")
            return None
        else:
            end_idx = start_idx + start_index_offset  # 转换为全局索引

        target_segment = log_lines[start_idx:end_idx + 1]
        # logger.info(f'target_segment:\n{target_segment}')
        final_list = list()
        for item in target_segment:
            item = item.strip()
            if item:
                final_list.append(item)
        return final_list

    except FileNotFoundError:
        logger.info(f"❌ 日志文件不存在：{log_file_path}，请检查文件路径是否正确")
        return None
    except Exception as e:
        logger.info(f"❌ 解析过程中发生错误：{str(e)}")
        return None

def parse_text_with_start_end(log_file_path, start_text, end_text='kd>'):
    """
    解析日志文件中从!devstack开始到ServiceName is结束的目标片段
    :param log_file_path: 日志文件路径（如level_2_log.txt）
    :return: 目标解析片段（字符串格式），若解析失败返回None
    """
    # logger.info(f'log_file_path:{log_file_path}')
    try:
        # 1. 读取日志文件内容（按行读取，保留原始格式）
        with open(log_file_path, 'r', encoding='utf-8', errors='ignore') as f:
            log_lines = f.readlines()  # 列表形式存储每一行日志，保留换行符

        # 2. 定位目标片段的起始行（包含"!devstack"的首行，即命令行起始）
        start_idx = None
        for idx, line in enumerate(log_lines):
            if start_text in line:  # 匹配起始标记
                start_idx = idx
                # logger.info(f'start_idx: {start_idx}')
                break
        if start_idx is None:
            logger.info(f"❌ 未在日志中找到起始标记:{start_text}")
            # logger.info(f'log_lines:{log_lines}')
            return None

        # 3. 定位目标片段的结束行（包含"ServiceName is"的行）
        end_idx = None
        # 从起始行之后开始查找，避免跨片段匹配
        for idx, line in enumerate(log_lines[start_idx+1:]):
            if end_text in line:
                end_idx = start_idx + idx  # 转换为全局索引
                break
        if end_idx is None:
            logger.info(f"❌ 未在日志中找到结束标记{end_text}")
            target_segment = log_lines[start_idx:]
        else:
            target_segment = log_lines[start_idx:end_idx + 1]

        # logger.info(f'target_segment:\n{target_segment}')
        final_list = list()
        for item in target_segment:
            item = item.strip()
            if item:
                final_list.append(item)
        return final_list

    except FileNotFoundError:
        logger.info(f"❌ 日志文件不存在：{log_file_path}，请检查文件路径是否正确")
        return None
    except Exception as e:
        logger.info(f"❌ 解析过程中发生错误：{str(e)}")
        return None

def append_file_content(source_file, target_file):
    """
    将源文件的内容追加到目标文件的末尾

    参数:
        source_file: 源文件路径
        target_file: 目标文件路径
    """
    try:
        # 以只读模式打开源文件
        with open(source_file, 'r', encoding="utf-8") as src:
            # 读取源文件内容
            content = src.read()

        # 以追加模式打开目标文件，如果文件不存在则创建
        with open(target_file, 'a', encoding="utf-8") as dest:
            # 追加内容到目标文件
            dest.write(content)

        # logger.info(f"成功将 {source_file} 的内容追加到 {target_file}")

    except FileNotFoundError:
        logger.info(f"错误: 文件 {source_file} 不存在")
    except Exception as e:
        logger.info(f"发生错误: {str(e)}")
    return

def extract_bugcheck_analysis(file_path):
    logger.info(f'file_path:{file_path}')
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            text = f.read()
    except FileNotFoundError:
        logger.info(f"错误：未找到文件{file_path}")
        exit()
    except Exception as e:
        logger.info(f"错误：读取文件失败，原因：{e}")
        exit()

    # 编译正则表达式（忽略大小写、允许跨行匹配）
    pattern = re.compile(
        r'Bugcheck\s+Analysis(.*?)Debugging\s+Details\s*:',
        re.DOTALL | re.IGNORECASE
    )

    # 搜索匹配内容
    match = pattern.search(text)

    if match:
        result = match.group(1).strip()
        result = result.replace('*', '').strip()
    else:
        result = ""
    return result

def extract_TRAP_FRAME_segment(log_file_path):
    """
    从log文件中提取以"CONTEXT: "开头的整段内容
    :param log_file_path: log文件的路径（需替换为你的实际路径）
    :return: 提取到的CONTEXT片段（字符串），若未找到则返回空字符串
    """
    # 初始化变量：存储结果、标记是否处于收集状态
    context_segment = []
    is_collecting = False
    content_flag = False

    try:
        # 逐行读取文件（避免一次性读取大文件占用内存）
        with open(log_file_path, 'r', encoding='utf-8') as f:
            for line in f:
                # 1. 检查是否触发"开始收集"条件（遇到CONTEXT: 开头的行）
                if line.startswith("CONTEXT: ") or line.startswith("TRAP_FRAME: "):
                    is_collecting = True
                    context_segment.append(line.rstrip('\n'))  # 保留原格式，仅去除自动添加的换行符
                # 2. 若处于收集状态，继续添加行，并检查是否触发"结束收集"条件
                elif is_collecting:
                    # 保留当前行的原始格式（包括换行符）
                    current_line = line.rstrip('\n')
                    context_segment.append(current_line)
                    # 结束标记：单独的".cxr"行（需排除带参数的.cxr行，如.cxr 0xffffd00021ad4a10）
                    if current_line.strip() == ".cxr":
                        is_collecting = False
                        break  # 片段结束，无需继续遍历
    except FileNotFoundError:
        logger.info(f"错误：未找到文件 {log_file_path}，请检查路径是否正确！")
        return "", content_flag
    except Exception as e:
        logger.info(f"解析文件时发生未知错误：{str(e)}")
        return "", content_flag

    # 将列表拼接为完整字符串（用换行符还原原始格式）
    result_str = None
    if len(context_segment):
        result_str = ' '.join(context_segment)
        if '?' in context_segment[-1]:
            content_flag = True
    return result_str, content_flag

def extract_Stack_Text_segment(log_file_path):
    """
    从log文件中提取以"CONTEXT: "开头的整段内容
    :param log_file_path: log文件的路径（需替换为你的实际路径）
    :return: 提取到的CONTEXT片段（字符串），若未找到则返回空字符串
    """
    # 初始化变量：存储结果、标记是否处于收集状态
    context_segment = []
    is_collecting = False
    Stack_Memory_Operation_Status = 0

    # 以nt!mi或nt!kipagefault或nt!Mm开头
    start_with_ntmi = False
    try:
        # 逐行读取文件（避免一次性读取大文件占用内存）
        with open(log_file_path, 'r', encoding='utf-8') as f:
            for line in f:
                # 1. 检查是否触发"开始收集"条件（遇到CONTEXT: 开头的行）
                if line.startswith("STACK_TEXT: "):
                    is_collecting = True
                    context_segment.append(line.rstrip('\n'))  # 保留原格式，仅去除自动添加的换行符
                # 2. 若处于收集状态，继续添加行，并检查是否触发"结束收集"条件
                elif is_collecting:
                    # 保留当前行的原始格式（包括换行符）
                    current_line = line.rstrip('\n')
                    context_segment.append(current_line)

                    current_line = current_line.strip()

                    # 结束标记：单独的".cxr"行（需排除带参数的.cxr行，如.cxr 0xffffd00021ad4a10）
                    if current_line == "":
                        is_collecting = False
                        break  # 片段结束，无需继续遍历
    except FileNotFoundError:
        logger.info(f"错误：未找到文件 {log_file_path}，请检查路径是否正确！")
        return "", Stack_Memory_Operation_Status
    except Exception as e:
        logger.info(f"解析文件时发生未知错误：{str(e)}")
        return "", Stack_Memory_Operation_Status

    Stack_Memory_Operation_Status = 0
    # 将列表拼接为完整字符串（用换行符还原原始格式）
    result_str = None
    if len(context_segment):
        result_str = ' '.join(context_segment)
    # logger.info(f'result_str:{result_str}')
    #
        index = 0
        for item in context_segment:
            if 'nt!KeBugCheck' in item:
                last_line = context_segment[index-1]
                if 'nt!mi' in last_line or 'nt!kipagefault' in last_line or 'nt!Mm' in last_line:
                    Stack_Memory_Operation_Status = 1
            index = index + 1

    return result_str, Stack_Memory_Operation_Status

def is_string_present(file_path: str, target_string: str, case_sensitive: bool = True) -> bool:
    """
    判断文件中是否包含指定字符串

    参数:
        file_path (str): 文件路径（绝对路径或相对路径）
        target_string (str): 要查找的目标字符串（如`nt!PopFxActivateDevice_Status`）
        case_sensitive (bool): 是否区分大小写（默认区分）

    返回:
        bool: 若文件存在且包含目标字符串，返回True；否则返回False

    异常处理:
        捕获FileNotFoundError（文件不存在）、PermissionError（无权限）等异常，返回False并打印警告
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            # 处理大小写（若不区分，转为小写）
            if not case_sensitive:
                target_string = target_string.lower()

            for line in f:
                # 逐行检查（避免读取大文件占用过多内存）
                current_line = line if case_sensitive else line.lower()
                if target_string in current_line:
                    return True  # 找到匹配，立即返回
        # 循环结束未找到，返回False
        return False

    except FileNotFoundError:
        logger.info(f"警告: 文件未找到 - {file_path}")
        return False
    except PermissionError:
        logger.info(f"警告: 无权限读取文件 - {file_path}")
        return False
    except Exception as e:
        logger.info(f"警告: 读取文件失败 - {file_path}，错误信息: {str(e)}")
        return False

def parse_file_by_pattern(file_path, patterns) -> list:
    # 1. 读取附件文件（替换为你的文件路径）
    # file_path = "3.log"  # 附件文件名，如3.log
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            text = f.read()
    except FileNotFoundError:
        logger.info(f"错误：未找到文件{file_path}")
        exit()
    except Exception as e:
        logger.info(f"错误：读取文件失败，原因：{e}")
        exit()

    # 3. 提取结果（处理可能的匹配失败）
    results = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, text)
        if match:
            results[key] = match.group(1)  # 取捕获组的内容（即字段后面的值）
        else:
            results[key] = NOT_FOUND  # 处理未匹配的情况

    # 4. 输出结果（直观展示）
    # logger.info(f"解析结果：{results}")
    return results

def read_file_by_line(file_name: str) -> list:
    """
    读取文本用例数据
    :param file_name: 文件路径
    :return: list
    """
    with open (file_name, "r") as file:
        for line in file:
            # my_log.info (line.strip ())
            pass
    return


def read_file_dict(file_name: str) -> dict:
    record_dic = {}
    if '.yaml' in file_name:
        with open(file_name, 'r', encoding='utf-8') as wf:
            record_dic = yaml.safe_load(wf)
    elif '.json' in file_name:
        with open (file_name, 'r') as wf:
            record_dic = json.load (wf)
    else:
        # my_log.info(f'file not support:{read_file_dict}')
        pass
    return record_dic

def dump_file(file_name, data) -> int:
    """
    读取文本用例数据
    :param file_name: 文件路径
    :return: list
    """
    # file_name = os.path.join(file_path, file_name)
    with open(file_name, 'w', encoding='utf-8') as wf:
        yaml.safe_dump(data, wf, default_flow_style=False, allow_unicode=True)
    return 0


def read_json_dict(file_name: str) -> dict:
    """
    读取文本用例数据
    :param file_name: 文件路径
    :return: list
    """
    data_dic = {}
    with open(file_name, 'r') as wf:
        data_dic = json.load(wf)
    return data_dic

def read_file_str(file_name):
    """
    读取文本用例数据
    :param file_name: 文件路径
    :return: list
    """
    # 打开文件，返回一个文件对象
    with open(file_name, 'r', encoding='gbk') as file:
        # 读取文件的全部内容
        content = file.read ()
        # my_log.info(content)
    return content

def wrtie_file(file_name, content) -> None:
    # 打开文件，如果文件不存在，会创建文件；'a' 表示追加模式，如果文件已存在，则会在文件末尾追加内容
    with open (file_name, 'w') as file:
        # 追加文本数据
        file.write(content)
    return

def add_string_to_first_line(file_path, new_string):
    try:
        # 以只读模式打开文件并读取所有内容
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()

        # 在内容开头插入新的字符串，并添加换行符
        lines.insert(0, new_string + '\n')

        # 以写入模式打开文件并将更新后的内容写回
        with open(file_path, 'w', encoding='utf-8') as file:
            file.writelines(lines)

        # logger.info(f"成功在文件 {file_path} 的第一行添加字符串。")
    except FileNotFoundError:
        logger.info(f"未找到文件: {file_path}")
    except Exception as e:
        logger.info(f"发生错误: {e}")
    return

def change_file_dict():
    file_name = r'D:\0_rope_skip_VIP\跳绳_last_model_count_VIP.yaml'
    data_dic = read_file_dict (file_name)
    target_dict = {}
    for file, file_dict in data_dic.items():
        new_file_dict = {}
        for key, value in file_dict.items():
            cell_dict = {}
            cell_dict.update({'fakeJumpTimes': 0})
            cell_dict.update ({'number': value})
            new_file_dict.update({f'{key}': cell_dict})
        target_dict.update({f'{file}': new_file_dict})

    # file = os.path.join (LOG_DIR, '跳绳_last_model_count_VIP.yaml')
    # dump_file (file, target_dict)
    return

def change_file_format():
    file_name = r'D:\configure_model_v2.8.0.json'
    data_dic = read_json_dict (file_name)

    file_name = r'D:\configure_model_v2.8.0_new.json'
    dump_json (file_name, data_dic)
    return

if __name__ == '__main__':
    # change_file_format()
    # change_file_dict()
    # covert_rope_cfg()
    # rope_analysis()
    current_enable = False
    if current_enable:
        data_dict = {}
        file = r'D:/hello.yaml'
        dump_file(file, data_dict)
    else:
        pass